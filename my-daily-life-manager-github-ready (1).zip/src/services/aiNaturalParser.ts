import { UniversalEntry, ModuleId } from '../types';
import { getCategories } from './storage';

export interface ParsedEntrySuggestion {
  moduleId: ModuleId;
  type: string;
  title: string;
  description?: string;
  amount?: number;
  paymentMode?: string;
  categoryId?: string;
  categoryName?: string;
  subcategory?: string;
  date: string;
  time: string;
  person?: string;
  priority?: 'critical' | 'high' | 'medium' | 'low';
  dueDate?: string;
  reminder?: boolean;
  confidence: number;
}

export function parseNaturalLanguageInput(rawText: string): ParsedEntrySuggestion {
  const text = rawText.trim();
  const lower = text.toLowerCase();
  
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const nowTime = new Date().toTimeString().slice(0, 5);

  let detectedDate = today;
  if (lower.includes('kal') || lower.includes('tomorrow') || lower.includes('આવતીકાલે') || lower.includes('next day')) {
    detectedDate = tomorrow;
  } else if (lower.includes('parso') || lower.includes('day after tomorrow')) {
    detectedDate = new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0];
  } else if (lower.includes('aaj') || lower.includes('today') || lower.includes('આજે')) {
    detectedDate = today;
  }

  // Detect time
  let detectedTime = nowTime;
  const timeMatch12h = text.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|pm|am)/i);
  const timeMatch24h = text.match(/(\d{1,2}):(\d{2})/);
  if (timeMatch12h) {
    let hour = parseInt(timeMatch12h[1], 10);
    const minute = timeMatch12h[2] ? timeMatch12h[2] : '00';
    const modifier = timeMatch12h[3].toLowerCase();
    if (modifier === 'pm' && hour < 12) hour += 12;
    if (modifier === 'am' && hour === 12) hour = 0;
    detectedTime = `${hour.toString().padStart(2, '0')}:${minute}`;
  } else if (timeMatch24h) {
    detectedTime = `${timeMatch24h[1].padStart(2, '0')}:${timeMatch24h[2]}`;
  }

  // Detect amount
  let detectedAmount: number | undefined;
  const amountMatch = text.match(/(?:₹|rs\.?|inr|rupees?|રૂપિયા|रुपये)?\s*(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:₹|rs\.?|inr|rupees?|રૂપિયા|रुपये|ka|ki|ke)?/i);
  if (amountMatch && amountMatch[1]) {
    const cleanNum = parseFloat(amountMatch[1].replace(/,/g, ''));
    if (!isNaN(cleanNum) && cleanNum > 0) {
      detectedAmount = cleanNum;
    }
  }

  // Detect Person
  let detectedPerson: string | undefined;
  const personMatch = text.match(/(?:with|ke saath|sathe|from|to|ko|by)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?(?:\s+(?:sir|bhai|ji|madam))?)/i);
  if (personMatch && personMatch[1]) {
    detectedPerson = personMatch[1];
  } else {
    const honorificMatch = text.match(/([A-Za-z]+)\s+(?:sir|bhai|ji|madam|sahab)/i);
    if (honorificMatch) {
      detectedPerson = `${honorificMatch[1]} ${honorificMatch[0].split(' ')[1]}`;
    }
  }

  // Detect Module & Type
  let detectedModule: ModuleId = 'personal';
  let detectedType = 'Personal work';
  let categoryName = 'Personal Work';
  let priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  let reminder = false;

  const isExpense =
    lower.includes('expense') ||
    lower.includes('kharcha') ||
    lower.includes('kharid') ||
    lower.includes('spent') ||
    lower.includes('paid') ||
    lower.includes('pay kiya') ||
    lower.includes('kharch') ||
    lower.includes('ખર્ચ') ||
    lower.includes('ખરીદી');

  const isCredit =
    lower.includes('salary') ||
    lower.includes('income') ||
    lower.includes('reimbursement') ||
    lower.includes('received') ||
    lower.includes('mila') ||
    lower.includes('aaye') ||
    lower.includes('credited') ||
    lower.includes('આવક') ||
    lower.includes('પગાર');

  const isBill =
    lower.includes('bill') ||
    lower.includes('electricity') ||
    lower.includes('bijli') ||
    lower.includes('mobile recharge') ||
    lower.includes('wifi') ||
    lower.includes('broadband') ||
    lower.includes('rent') ||
    lower.includes('emi') ||
    lower.includes('વીજળી બિલ') ||
    lower.includes('ભાડું');

  const isUnion =
    lower.includes('union') ||
    lower.includes('sangathan') ||
    lower.includes('morcha') ||
    lower.includes('representation') ||
    lower.includes('grievance') ||
    lower.includes('circular') ||
    lower.includes('general body') ||
    lower.includes('મંડળ') ||
    lower.includes('યુનિયન');

  const isOffice =
    lower.includes('office') ||
    lower.includes('file work') ||
    lower.includes('report') ||
    lower.includes('boss') ||
    lower.includes('manager') ||
    lower.includes('desk') ||
    lower.includes('karyalay') ||
    lower.includes('ઓફિસ');

  const isTask =
    lower.includes('task') ||
    lower.includes('karna hai') ||
    lower.includes('pending') ||
    lower.includes('baki hai') ||
    lower.includes('complete') ||
    lower.includes('submit') ||
    lower.includes('કામ');

  const isMeeting =
    lower.includes('meeting') ||
    lower.includes('call') ||
    lower.includes('appointment') ||
    lower.includes('charcha') ||
    lower.includes('મુલાકાત');

  if (isExpense) {
    detectedModule = 'expense';
    detectedType = 'Expense';
    if (isOffice) categoryName = 'Office Expense';
    else if (isUnion) categoryName = 'Union Expense';
    else if (lower.includes('petrol') || lower.includes('fuel') || lower.includes('diesel')) categoryName = 'Vehicle';
    else if (lower.includes('food') || lower.includes('khana') || lower.includes('dinner') || lower.includes('lunch')) categoryName = 'Food & Dining';
    else categoryName = 'Personal Expense';
  } else if (isCredit) {
    detectedModule = 'credit';
    detectedType = 'Credit / Income';
    if (lower.includes('salary') || lower.includes('pagar')) categoryName = 'Salary';
    else if (lower.includes('reimbursement')) categoryName = 'Reimbursement';
    else categoryName = 'Money Received';
  } else if (isBill) {
    detectedModule = 'bills';
    detectedType = 'Bill';
    if (lower.includes('electricity') || lower.includes('bijli')) categoryName = 'Electricity';
    else if (lower.includes('mobile')) categoryName = 'Mobile & Phone';
    else if (lower.includes('wifi') || lower.includes('internet')) categoryName = 'Internet / WiFi';
    else categoryName = 'Bills';
  } else if (isUnion) {
    detectedModule = 'union';
    detectedType = isMeeting ? 'Meeting' : 'Union Activity';
    categoryName = isMeeting ? 'Meeting' : 'Member Issues';
    priority = 'high';
  } else if (isOffice) {
    detectedModule = 'office';
    detectedType = isMeeting ? 'Meeting' : 'Office work';
    categoryName = isMeeting ? 'Meeting' : 'Office Work';
    priority = 'high';
  } else if (isTask) {
    detectedModule = 'tasks';
    detectedType = 'Task';
    categoryName = 'Personal Tasks';
    priority = 'medium';
  }

  if (isMeeting || detectedTime !== nowTime) {
    reminder = true;
  }

  // Match existing category ID from storage
  const allCategories = getCategories(detectedModule);
  const matchedCat = allCategories.find((c) => c.name.toLowerCase() === categoryName.toLowerCase()) || allCategories[0];

  // Clean title
  let cleanTitle = text;
  if (cleanTitle.length > 50) {
    cleanTitle = cleanTitle.slice(0, 48) + '...';
  }

  return {
    moduleId: detectedModule,
    type: detectedType,
    title: cleanTitle,
    description: text,
    amount: detectedAmount,
    categoryId: matchedCat?.id,
    categoryName: matchedCat?.name || categoryName,
    date: detectedDate,
    time: detectedTime,
    person: detectedPerson,
    priority,
    dueDate: detectedDate,
    reminder,
    confidence: 0.88,
  };
}
