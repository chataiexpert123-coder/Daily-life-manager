import * as XLSX from 'xlsx';
import {
  UniversalEntry,
  CategoryItem,
  CustomTabConfig,
  AffirmationItem,
  DailyDiaryEntry,
  AppSettings,
  CustomField,
  SyncLogItem,
} from '../types';
import {
  DEFAULT_TABS,
  DEFAULT_CATEGORIES,
  DEFAULT_AFFIRMATIONS,
  DEFAULT_SETTINGS,
  generateInitialSampleEntries,
  generateInitialDiaryEntries,
} from './defaultData';

const STORAGE_KEYS = {
  ENTRIES: 'mydlm_entries_v1',
  TABS: 'mydlm_tabs_v1',
  CATEGORIES: 'mydlm_categories_v1',
  AFFIRMATIONS: 'mydlm_affirmations_v1',
  DIARY: 'mydlm_diary_v1',
  SETTINGS: 'mydlm_settings_v1',
  SYNC_LOGS: 'mydlm_sync_logs_v1',
  PENDING_SYNC: 'mydlm_pending_sync_v1',
  INITIALIZED: 'mydlm_initialized_v1',
};

type StorageListener = () => void;
const listeners = new Set<StorageListener>();

export function subscribeToStorage(callback: StorageListener): () => void {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

function notifyStorageChange() {
  listeners.forEach((cb) => {
    try {
      cb();
    } catch (e) {
      console.error('Storage subscriber error', e);
    }
  });
}

// Initialize default storage data on first run
export function initializeStorage(): void {
  try {
    const isInit = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
    if (!isInit) {
      localStorage.setItem(STORAGE_KEYS.TABS, JSON.stringify(DEFAULT_TABS));
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
      localStorage.setItem(STORAGE_KEYS.AFFIRMATIONS, JSON.stringify(DEFAULT_AFFIRMATIONS));
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
      localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(generateInitialSampleEntries()));
      localStorage.setItem(STORAGE_KEYS.DIARY, JSON.stringify(generateInitialDiaryEntries()));
      localStorage.setItem(STORAGE_KEYS.SYNC_LOGS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PENDING_SYNC, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    }
  } catch (err) {
    console.error('Error initializing local storage:', err);
  }
}

// ----------------------------------------------------------------------
// Universal Entries CRUD
// ----------------------------------------------------------------------

export function getEntries(): UniversalEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ENTRIES);
    if (!raw) return [];
    const entries: UniversalEntry[] = JSON.parse(raw);
    return entries.sort((a, b) => {
      // Sort newest date & time first
      const dateA = `${a.date} ${a.time || '00:00'}`;
      const dateB = `${b.date} ${b.time || '00:00'}`;
      return dateB.localeCompare(dateA);
    });
  } catch (err) {
    console.error('Error loading entries:', err);
    return [];
  }
}

export function saveEntry(entry: UniversalEntry): UniversalEntry {
  const entries = getEntries();
  const index = entries.findIndex((e) => e.id === entry.id);
  const now = new Date().toISOString();

  let updatedEntry: UniversalEntry;
  if (index >= 0) {
    updatedEntry = {
      ...entries[index],
      ...entry,
      updatedAt: now,
    };
    entries[index] = updatedEntry;
  } else {
    updatedEntry = {
      ...entry,
      id: entry.id || `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      createdAt: entry.createdAt || now,
      updatedAt: now,
    };
    entries.unshift(updatedEntry);
  }

  localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
  queueForSync('entry', updatedEntry.id, index >= 0 ? 'update' : 'create', updatedEntry);
  notifyStorageChange();
  return updatedEntry;
}

export function deleteEntry(entryId: string): void {
  const entries = getEntries();
  const target = entries.find((e) => e.id === entryId);
  const filtered = entries.filter((e) => e.id !== entryId);
  localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(filtered));
  if (target) {
    queueForSync('entry', entryId, 'delete', { id: entryId });
  }
  notifyStorageChange();
}

export function archiveEntry(entryId: string, archive: boolean = true): void {
  const entries = getEntries();
  const index = entries.findIndex((e) => e.id === entryId);
  if (index >= 0) {
    entries[index].isArchived = archive;
    entries[index].updatedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
    queueForSync('entry', entryId, 'update', entries[index]);
    notifyStorageChange();
  }
}

export function duplicateEntry(entryId: string): UniversalEntry | null {
  const entries = getEntries();
  const source = entries.find((e) => e.id === entryId);
  if (!source) return null;

  const today = new Date().toISOString().split('T')[0];
  const nowTime = new Date().toTimeString().slice(0, 5);

  const duplicate: UniversalEntry = {
    ...JSON.parse(JSON.stringify(source)),
    id: `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    title: `${source.title} (Copy)`,
    date: today,
    time: nowTime,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  };

  return saveEntry(duplicate);
}

// ----------------------------------------------------------------------
// Custom Tabs CRUD
// ----------------------------------------------------------------------

export function getTabs(): CustomTabConfig[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TABS);
    if (!raw) return DEFAULT_TABS;
    const tabs: CustomTabConfig[] = JSON.parse(raw);
    return tabs.sort((a, b) => a.order - b.order);
  } catch (err) {
    console.error('Error loading tabs:', err);
    return DEFAULT_TABS;
  }
}

export function saveTab(tab: CustomTabConfig): void {
  const tabs = getTabs();
  const index = tabs.findIndex((t) => t.id === tab.id);
  if (index >= 0) {
    tabs[index] = tab;
  } else {
    tabs.push({
      ...tab,
      order: tabs.length,
      isCustom: true,
    });
  }
  localStorage.setItem(STORAGE_KEYS.TABS, JSON.stringify(tabs));
  queueForSync('tab', tab.id, 'update', tab);
  notifyStorageChange();
}

export function deleteTab(tabId: string): { success: boolean; message?: string } {
  // Check if entries use this tab / moduleId
  const entries = getEntries();
  const usedCount = entries.filter((e) => e.moduleId === tabId).length;
  if (usedCount > 0) {
    return {
      success: false,
      message: `This tab has ${usedCount} associated entries. Please archive it instead so historical records are preserved.`,
    };
  }

  const tabs = getTabs().filter((t) => t.id !== tabId);
  localStorage.setItem(STORAGE_KEYS.TABS, JSON.stringify(tabs));
  notifyStorageChange();
  return { success: true };
}

// ----------------------------------------------------------------------
// Categories CRUD (with Safe Archiving & Renaming Propagation)
// ----------------------------------------------------------------------

export function getCategories(moduleId?: string): CategoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) return DEFAULT_CATEGORIES;
    let categories: CategoryItem[] = JSON.parse(raw);
    if (moduleId) {
      categories = categories.filter((c) => c.moduleId === moduleId);
    }
    return categories.sort((a, b) => a.order - b.order);
  } catch (err) {
    console.error('Error loading categories:', err);
    return DEFAULT_CATEGORIES;
  }
}

export function saveCategory(category: CategoryItem): CategoryItem {
  const categories = getCategories();
  const index = categories.findIndex((c) => c.id === category.id);
  let saved: CategoryItem;

  if (index >= 0) {
    const oldCategory = categories[index];
    saved = { ...oldCategory, ...category };
    categories[index] = saved;

    // If name changed, propagate update to existing entries so historical display remains intact
    if (oldCategory.name !== category.name) {
      const entries = getEntries();
      let hasModified = false;
      entries.forEach((e) => {
        if (e.categoryId === category.id) {
          e.categoryName = category.name;
          e.updatedAt = new Date().toISOString();
          hasModified = true;
        }
      });
      if (hasModified) {
        localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
      }
    }
  } else {
    saved = {
      ...category,
      id: category.id || `cat-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      order: category.order ?? categories.length,
      subcategories: category.subcategories || [],
      isArchived: false,
    };
    categories.push(saved);
  }

  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  queueForSync('category', saved.id, 'update', saved);
  notifyStorageChange();
  return saved;
}

export function checkCategoryUsage(categoryId: string): number {
  const entries = getEntries();
  return entries.filter((e) => e.categoryId === categoryId).length;
}

export function archiveCategory(categoryId: string, archive: boolean = true): void {
  const categories = getCategories();
  const index = categories.findIndex((c) => c.id === categoryId);
  if (index >= 0) {
    categories[index].isArchived = archive;
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    queueForSync('category', categoryId, 'update', categories[index]);
    notifyStorageChange();
  }
}

export function deleteCategory(categoryId: string): { success: boolean; usedCount: number; message?: string } {
  const usedCount = checkCategoryUsage(categoryId);
  if (usedCount > 0) {
    return {
      success: false,
      usedCount,
      message: `This category is already used by ${usedCount} existing records. You can archive it so it will no longer appear for new entries while historical records remain unchanged.`,
    };
  }

  const categories = getCategories().filter((c) => c.id !== categoryId);
  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  notifyStorageChange();
  return { success: true, usedCount: 0 };
}

// ----------------------------------------------------------------------
// Affirmations CRUD
// ----------------------------------------------------------------------

export function getAffirmations(lang?: 'en' | 'hi' | 'gu'): AffirmationItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AFFIRMATIONS);
    if (!raw) return DEFAULT_AFFIRMATIONS;
    let list: AffirmationItem[] = JSON.parse(raw);
    if (lang) {
      list = list.filter((a) => a.language === lang);
    }
    return list;
  } catch (err) {
    console.error('Error loading affirmations:', err);
    return DEFAULT_AFFIRMATIONS;
  }
}

export function saveAffirmation(affirmation: AffirmationItem): AffirmationItem {
  const list = getAffirmations();
  const index = list.findIndex((a) => a.id === affirmation.id);
  let saved: AffirmationItem;

  if (index >= 0) {
    saved = { ...list[index], ...affirmation };
    list[index] = saved;
  } else {
    saved = {
      ...affirmation,
      id: affirmation.id || `aff-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    };
    list.push(saved);
  }

  localStorage.setItem(STORAGE_KEYS.AFFIRMATIONS, JSON.stringify(list));
  notifyStorageChange();
  return saved;
}

export function deleteAffirmation(id: string): void {
  const list = getAffirmations().filter((a) => a.id !== id);
  localStorage.setItem(STORAGE_KEYS.AFFIRMATIONS, JSON.stringify(list));
  notifyStorageChange();
}

// ----------------------------------------------------------------------
// Daily Diary CRUD
// ----------------------------------------------------------------------

export function getDiaryEntries(): DailyDiaryEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DIARY);
    if (!raw) return generateInitialDiaryEntries();
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading diary entries:', err);
    return [];
  }
}

export function getDiaryEntryByDate(date: string): DailyDiaryEntry | undefined {
  const entries = getDiaryEntries();
  return entries.find((d) => d.date === date);
}

export function saveDiaryEntry(entry: DailyDiaryEntry): DailyDiaryEntry {
  const list = getDiaryEntries();
  const index = list.findIndex((d) => d.date === entry.date);
  const now = new Date().toISOString();

  let saved: DailyDiaryEntry;
  if (index >= 0) {
    saved = { ...list[index], ...entry, updatedAt: now };
    list[index] = saved;
  } else {
    saved = {
      ...entry,
      id: entry.id || `diary-${entry.date}`,
      updatedAt: now,
    };
    list.push(saved);
  }

  localStorage.setItem(STORAGE_KEYS.DIARY, JSON.stringify(list));
  queueForSync('diary', saved.id, 'update', saved);
  notifyStorageChange();
  return saved;
}

// ----------------------------------------------------------------------
// Settings CRUD
// ----------------------------------------------------------------------

export function getSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (err) {
    console.error('Error loading settings:', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Partial<AppSettings>): AppSettings {
  const current = getSettings();
  const updated: AppSettings = { ...current, ...settings };
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updated));
  notifyStorageChange();
  return updated;
}

// ----------------------------------------------------------------------
// Sync Logs & Queue
// ----------------------------------------------------------------------

export function getSyncLogs(): SyncLogItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SYNC_LOGS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addSyncLog(log: Omit<SyncLogItem, 'id' | 'timestamp'>): void {
  const logs = getSyncLogs();
  const newLog: SyncLogItem = {
    ...log,
    id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    timestamp: new Date().toISOString(),
  };
  logs.unshift(newLog);
  // Keep max 100 logs
  localStorage.setItem(STORAGE_KEYS.SYNC_LOGS, JSON.stringify(logs.slice(0, 100)));
  notifyStorageChange();
}

export function queueForSync(entityType: string, entityId: string, operation: string, payload: any): void {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PENDING_SYNC);
    const queue = raw ? JSON.parse(raw) : [];
    queue.push({
      id: `queue-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      entityType,
      entityId,
      operation,
      payload,
      queuedAt: new Date().toISOString(),
    });
    localStorage.setItem(STORAGE_KEYS.PENDING_SYNC, JSON.stringify(queue));
  } catch (e) {
    console.error('Error queuing for sync:', e);
  }
}

export function getPendingSyncQueue(): any[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PENDING_SYNC);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function clearPendingSyncQueue(): void {
  localStorage.setItem(STORAGE_KEYS.PENDING_SYNC, JSON.stringify([]));
  notifyStorageChange();
}

// ----------------------------------------------------------------------
// Export & Backup
// ----------------------------------------------------------------------

export function exportFullBackupJSON(): string {
  const backup = {
    version: '1.0',
    exportedAt: new Date().toISOString(),
    app: 'My Daily Life Manager',
    entries: getEntries(),
    tabs: getTabs(),
    categories: getCategories(),
    affirmations: getAffirmations(),
    diary: getDiaryEntries(),
    settings: getSettings(),
  };
  return JSON.stringify(backup, null, 2);
}

export function exportToExcel(entriesToExport?: UniversalEntry[], filenamePrefix: string = 'MyDailyLifeManager'): void {
  const entries = entriesToExport || getEntries();
  const wb = XLSX.utils.book_new();

  // 1. All Entries Sheet
  const allRows = entries.map((e) => ({
    ID: e.id,
    Date: e.date,
    Time: e.time || '',
    Module: e.moduleId,
    Type: e.type,
    Title: e.title,
    Category: e.categoryName || '',
    Subcategory: e.subcategory || '',
    Priority: e.priority || '',
    Status: e.status || '',
    Amount: e.amount ?? '',
    'Payment Mode': e.paymentMode || '',
    'Person / Vendor': e.vendorOrPerson || e.person || '',
    Organization: e.organization || '',
    'Due Date': e.dueDate || '',
    'Ref / File No': e.referenceNumber || e.fileNumber || '',
    Tags: (e.tags || []).join(', '),
    Description: e.description || '',
    Archived: e.isArchived ? 'Yes' : 'No',
    'Created At': e.createdAt,
    'Updated At': e.updatedAt,
  }));
  const wsAll = XLSX.utils.json_to_sheet(allRows);
  XLSX.utils.book_append_sheet(wb, wsAll, 'All Entries');

  // 2. Expenses Sheet
  const expenses = entries.filter((e) => e.moduleId === 'expense' || e.type === 'Expense');
  if (expenses.length > 0) {
    const wsExp = XLSX.utils.json_to_sheet(
      expenses.map((e) => ({
        Date: e.date,
        Time: e.time,
        Title: e.title,
        Category: e.categoryName,
        Subcategory: e.subcategory,
        Amount: e.amount,
        'Payment Mode': e.paymentMode,
        Vendor: e.vendorOrPerson,
        'Bill No': e.billNumber,
        GST: e.gstNumber,
        Description: e.description,
      }))
    );
    XLSX.utils.book_append_sheet(wb, wsExp, 'Expenses');
  }

  // 3. Credits Sheet
  const credits = entries.filter((e) => e.moduleId === 'credit' || e.type === 'Credit / Income');
  if (credits.length > 0) {
    const wsCrd = XLSX.utils.json_to_sheet(
      credits.map((e) => ({
        Date: e.date,
        Time: e.time,
        Title: e.title,
        Category: e.categoryName,
        Source: e.vendorOrPerson,
        Amount: e.amount,
        'Payment Mode': e.paymentMode,
        Reference: e.referenceNumber,
        Description: e.description,
      }))
    );
    XLSX.utils.book_append_sheet(wb, wsCrd, 'Credits');
  }

  // 4. Bills Sheet
  const bills = entries.filter((e) => e.moduleId === 'bills' || e.type === 'Bill');
  if (bills.length > 0) {
    const wsBills = XLSX.utils.json_to_sheet(
      bills.map((e) => ({
        'Bill Name': e.title,
        Provider: e.vendorOrPerson,
        Category: e.categoryName,
        Amount: e.amount,
        'Due Date': e.dueDate,
        Status: e.status,
        'Payment Mode': e.paymentMode,
      }))
    );
    XLSX.utils.book_append_sheet(wb, wsBills, 'Bills');
  }

  // 5. Tasks Sheet
  const tasks = entries.filter((e) => e.moduleId === 'tasks' || e.type === 'Task');
  if (tasks.length > 0) {
    const wsTasks = XLSX.utils.json_to_sheet(
      tasks.map((e) => ({
        Task: e.title,
        Category: e.categoryName,
        Priority: e.priority,
        Status: e.status,
        'Due Date': e.dueDate,
        Subtasks: (e.subtasks || []).map((s) => `${s.isCompleted ? '[X]' : '[ ]'} ${s.title}`).join(' | '),
        Description: e.description,
      }))
    );
    XLSX.utils.book_append_sheet(wb, wsTasks, 'Tasks');
  }

  // Download
  XLSX.writeFile(wb, `${filenamePrefix}_${new Date().toISOString().split('T')[0]}.xlsx`);
}

export function exportToCSV(entriesToExport?: UniversalEntry[], filenamePrefix: string = 'MyDailyLifeManager_Entries'): void {
  const entries = entriesToExport || getEntries();
  const allRows = entries.map((e) => ({
    ID: e.id,
    Date: e.date,
    Time: e.time || '',
    Module: e.moduleId,
    Type: e.type,
    Title: e.title,
    Category: e.categoryName || '',
    Subcategory: e.subcategory || '',
    Priority: e.priority || '',
    Status: e.status || '',
    Amount: e.amount ?? '',
    'Payment Mode': e.paymentMode || '',
    Person_Vendor: e.vendorOrPerson || e.person || '',
    Organization: e.organization || '',
    Due_Date: e.dueDate || '',
    Ref_File_No: e.referenceNumber || e.fileNumber || '',
    Tags: (e.tags || []).join('; '),
    Description: e.description || '',
    Archived: e.isArchived ? 'Yes' : 'No',
    Created_At: e.createdAt,
    Updated_At: e.updatedAt,
  }));
  const ws = XLSX.utils.json_to_sheet(allRows);
  const csv = XLSX.utils.sheet_to_csv(ws);
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filenamePrefix}_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// ----------------------------------------------------------------------
// Import & Restore
// ----------------------------------------------------------------------

export interface ImportResult {
  recordsFound: number;
  imported: number;
  skipped: number;
  errors: string[];
}

export function importEntriesFromJSON(jsonString: string): ImportResult {
  const result: ImportResult = { recordsFound: 0, imported: 0, skipped: 0, errors: [] };
  try {
    const data = JSON.parse(jsonString);
    let itemsToImport: any[] = [];

    if (Array.isArray(data)) {
      itemsToImport = data;
    } else if (data.entries && Array.isArray(data.entries)) {
      itemsToImport = data.entries;
    } else {
      result.errors.push('Unrecognized JSON structure. Expected array of entries or backup object with .entries property.');
      return result;
    }

    result.recordsFound = itemsToImport.length;
    const existingEntries = getEntries();
    const existingIds = new Set(existingEntries.map((e) => e.id));

    itemsToImport.forEach((item, index) => {
      if (!item.title) {
        result.skipped++;
        result.errors.push(`Row ${index + 1}: Missing title`);
        return;
      }

      const id = item.id || `entry-imp-${Date.now()}-${index}`;
      if (existingIds.has(id)) {
        result.skipped++;
        return;
      }

      const normalized: UniversalEntry = {
        id,
        moduleId: item.moduleId || 'personal',
        type: item.type || 'Personal work',
        date: item.date || new Date().toISOString().split('T')[0],
        time: item.time || '12:00',
        title: item.title,
        description: item.description || '',
        categoryId: item.categoryId,
        categoryName: item.categoryName,
        subcategory: item.subcategory,
        priority: item.priority || 'medium',
        status: item.status || 'pending',
        tags: Array.isArray(item.tags) ? item.tags : [],
        amount: typeof item.amount === 'number' ? item.amount : undefined,
        paymentMode: item.paymentMode,
        vendorOrPerson: item.vendorOrPerson || item.person,
        organization: item.organization,
        referenceNumber: item.referenceNumber,
        fileNumber: item.fileNumber,
        dueDate: item.dueDate,
        attachments: Array.isArray(item.attachments) ? item.attachments : [],
        subtasks: Array.isArray(item.subtasks) ? item.subtasks : [],
        isArchived: Boolean(item.isArchived),
        createdAt: item.createdAt || new Date().toISOString(),
        updatedAt: item.updatedAt || new Date().toISOString(),
      };

      existingEntries.push(normalized);
      existingIds.add(id);
      result.imported++;
    });

    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(existingEntries));
    notifyStorageChange();
  } catch (err: any) {
    result.errors.push(`JSON Parse failed: ${err.message}`);
  }
  return result;
}

export function restoreFullBackup(backupData: any): { success: boolean; message: string } {
  try {
    if (!backupData || !backupData.entries) {
      return { success: false, message: 'Invalid backup file structure.' };
    }

    if (backupData.entries) localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(backupData.entries));
    if (backupData.tabs) localStorage.setItem(STORAGE_KEYS.TABS, JSON.stringify(backupData.tabs));
    if (backupData.categories) localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(backupData.categories));
    if (backupData.affirmations) localStorage.setItem(STORAGE_KEYS.AFFIRMATIONS, JSON.stringify(backupData.affirmations));
    if (backupData.diary) localStorage.setItem(STORAGE_KEYS.DIARY, JSON.stringify(backupData.diary));
    if (backupData.settings) localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(backupData.settings));

    notifyStorageChange();
    return { success: true, message: `Successfully restored ${backupData.entries.length} entries, custom categories, tabs, and settings.` };
  } catch (err: any) {
    return { success: false, message: `Restore failed: ${err.message}` };
  }
}

// Reset data to defaults
export function resetToDemoData(): void {
  localStorage.setItem(STORAGE_KEYS.TABS, JSON.stringify(DEFAULT_TABS));
  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
  localStorage.setItem(STORAGE_KEYS.AFFIRMATIONS, JSON.stringify(DEFAULT_AFFIRMATIONS));
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
  localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(generateInitialSampleEntries()));
  localStorage.setItem(STORAGE_KEYS.DIARY, JSON.stringify(generateInitialDiaryEntries()));
  localStorage.setItem(STORAGE_KEYS.SYNC_LOGS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.PENDING_SYNC, JSON.stringify([]));
  notifyStorageChange();
}

export const updateSettings = saveSettings;
export const exportEntriesToExcel = exportToExcel;
export const exportEntriesToCSV = exportToCSV;
export const resetToFactoryDefaults = resetToDemoData;
export function importFullBackupJSON(jsonString: string): boolean {
  try {
    const parsed = JSON.parse(jsonString);
    const res = restoreFullBackup(parsed);
    return res.success;
  } catch {
    return false;
  }
}

