import React from 'react';
import { AlertTriangle, Archive, Trash2, X } from 'lucide-react';

interface SafeCategoryModalProps {
  isOpen: boolean;
  categoryName: string;
  usedCount: number;
  onCancel: () => void;
  onArchive: () => void;
  onForceDelete?: () => void;
}

export const SafeCategoryModal: React.FC<SafeCategoryModalProps> = ({
  isOpen,
  categoryName,
  usedCount,
  onCancel,
  onArchive,
  onForceDelete,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-4">
        <div className="flex items-start space-x-3">
          <div className="p-2.5 bg-amber-100 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 rounded-xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Safe Category Deletion
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Category: <span className="font-semibold text-slate-800 dark:text-slate-200">"{categoryName}"</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 p-3.5 rounded-xl text-xs leading-relaxed text-amber-900 dark:text-amber-200">
          This category is already used by <span className="font-bold">{usedCount}</span> existing records.
          <br /><br />
          You can <strong>Archive</strong> it so it will no longer appear in new-entry dropdowns while all your historical records, reports, Excel exports, and Google Sheets remain intact.
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-end gap-2 pt-2">
          <button
            type="button"
            id="modal_cancel_btn"
            onClick={onCancel}
            className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Cancel
          </button>
          
          {onForceDelete && (
            <button
              type="button"
              id="modal_delete_btn"
              onClick={onForceDelete}
              className="w-full sm:w-auto px-3.5 py-2 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Anyway</span>
            </button>
          )}

          <button
            type="button"
            id="modal_archive_btn"
            onClick={onArchive}
            className="w-full sm:w-auto px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-500/20 transition-all flex items-center justify-center gap-1.5"
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Archive Category (Recommended)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
