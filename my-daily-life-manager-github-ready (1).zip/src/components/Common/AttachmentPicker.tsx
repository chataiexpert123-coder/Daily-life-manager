import React, { useRef, useState } from 'react';
import { Camera, Paperclip, X, Eye, FileText, Image as ImageIcon, Plus } from 'lucide-react';
import { AttachmentItem } from '../../types';

interface AttachmentPickerProps {
  attachments: AttachmentItem[];
  onChange: (attachments: AttachmentItem[]) => void;
}

export const AttachmentPicker: React.FC<AttachmentPickerProps> = ({
  attachments = [],
  onChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const [previewItem, setPreviewItem] = useState<AttachmentItem | null>(null);

  // Compress image before storing
  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const maxDim = 1200;

          if (width > height && width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.8));
        };
      };
    });
  };

  const handleFileSelection = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newItems: AttachmentItem[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImg = file.type.startsWith('image/');
      const isPdf = file.type === 'application/pdf';

      let dataUrl = '';
      if (isImg) {
        dataUrl = await compressImage(file);
      } else {
        // Read as data URL
        dataUrl = await new Promise((res) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => res(reader.result as string);
        });
      }

      newItems.push({
        id: `att-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 4)}`,
        name: file.name,
        type: isImg ? 'image' : isPdf ? 'pdf' : 'document',
        dataUrl,
        size: file.size,
        uploadedAt: new Date().toISOString(),
      });
    }

    onChange([...attachments, ...newItems]);
    if (e.target) e.target.value = '';
  };

  const removeAttachment = (id: string) => {
    onChange(attachments.filter((a) => a.id !== id));
  };

  return (
    <div id="attachment_picker_container" className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
          <Paperclip className="w-3.5 h-3.5 text-indigo-500" />
          <span>Photos & Documents</span>
          <span className="text-[11px] font-normal text-slate-400">({attachments.length})</span>
        </label>

        <div className="flex items-center space-x-2">
          {/* Camera Button */}
          <button
            type="button"
            id="camera_capture_btn"
            onClick={() => cameraInputRef.current?.click()}
            className="flex items-center space-x-1 px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-lg hover:bg-slate-200 transition-colors"
          >
            <Camera className="w-3.5 h-3.5 text-indigo-500" />
            <span>Camera</span>
          </button>
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handleFileSelection}
          />

          {/* Files Button */}
          <button
            type="button"
            id="file_upload_btn"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1 px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-xs font-semibold rounded-lg hover:bg-indigo-100 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add File</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
            className="hidden"
            onChange={handleFileSelection}
          />
        </div>
      </div>

      {/* Attachment Grid */}
      {attachments.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 pt-1">
          {attachments.map((item) => (
            <div
              key={item.id}
              className="group relative rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 aspect-square flex flex-col items-center justify-center p-1.5 shadow-sm"
            >
              {item.type === 'image' && item.dataUrl ? (
                <img
                  src={item.dataUrl}
                  alt={item.name}
                  className="w-full h-full object-cover rounded"
                />
              ) : (
                <div className="flex flex-col items-center justify-center text-center p-1">
                  <FileText className="w-6 h-6 text-indigo-500 mb-1" />
                  <span className="text-[10px] font-medium text-slate-700 dark:text-slate-300 line-clamp-2 break-all">
                    {item.name}
                  </span>
                </div>
              )}

              {/* Action Overlays */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2">
                {item.dataUrl && (
                  <button
                    type="button"
                    onClick={() => setPreviewItem(item)}
                    className="p-1 bg-white/90 rounded-full text-slate-800 hover:bg-white transition-transform active:scale-95"
                    title="View"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => removeAttachment(item.id)}
                  className="p-1 bg-rose-600 rounded-full text-white hover:bg-rose-700 transition-transform active:scale-95"
                  title="Remove"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Fullscreen Lightbox Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-4">
          <div className="relative max-w-2xl w-full bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shadow-2xl p-4">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-200 dark:border-slate-800">
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate pr-4">
                {previewItem.name}
              </span>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[70vh] flex items-center justify-center overflow-auto rounded-lg bg-slate-950/5 dark:bg-slate-950 p-2">
              {previewItem.type === 'image' && previewItem.dataUrl ? (
                <img
                  src={previewItem.dataUrl}
                  alt={previewItem.name}
                  className="max-h-[65vh] w-auto object-contain rounded"
                />
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 text-indigo-500 mx-auto mb-3" />
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    {previewItem.name}
                  </p>
                  <a
                    href={previewItem.dataUrl}
                    download={previewItem.name}
                    className="inline-block mt-4 px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg"
                  >
                    Download Document
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
