import React from 'react';
import { CustomField } from '../../types';

interface CustomFieldsRendererProps {
  customFields: CustomField[];
  values: Record<string, any>;
  onChange: (values: Record<string, any>) => void;
  currencySymbol?: string;
}

export const CustomFieldsRenderer: React.FC<CustomFieldsRendererProps> = ({
  customFields,
  values = {},
  onChange,
  currencySymbol = '₹',
}) => {
  if (!customFields || customFields.length === 0) return null;

  const handleFieldChange = (fieldId: string, val: any) => {
    onChange({
      ...values,
      [fieldId]: val,
    });
  };

  return (
    <div id="custom_fields_container" className="space-y-3 pt-2">
      <div className="text-[11px] font-bold tracking-wider uppercase text-slate-400 dark:text-slate-500">
        Custom Fields
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {customFields.map((field) => {
          const val = values[field.id] ?? '';

          if (field.fieldType === 'checkbox') {
            return (
              <label
                key={field.id}
                className="flex items-center space-x-2 p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={Boolean(val)}
                  onChange={(e) => handleFieldChange(field.id, e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                />
                <span className="text-xs font-medium text-slate-800 dark:text-slate-200">
                  {field.name}
                  {field.isRequired && <span className="text-rose-500 ml-0.5">*</span>}
                </span>
              </label>
            );
          }

          if (field.fieldType === 'dropdown') {
            return (
              <div key={field.id} className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {field.name}
                  {field.isRequired && <span className="text-rose-500 ml-0.5">*</span>}
                </label>
                <select
                  value={val}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Select {field.name}...</option>
                  {(field.options || []).map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            );
          }

          if (field.fieldType === 'long_text') {
            return (
              <div key={field.id} className="sm:col-span-2 space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {field.name}
                  {field.isRequired && <span className="text-rose-500 ml-0.5">*</span>}
                </label>
                <textarea
                  rows={2}
                  value={val}
                  placeholder={`Enter ${field.name.toLowerCase()}...`}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            );
          }

          return (
            <div key={field.id} className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {field.name}
                {field.isRequired && <span className="text-rose-500 ml-0.5">*</span>}
              </label>
              <div className="relative">
                {field.fieldType === 'currency' && (
                  <span className="absolute left-3 top-2 text-xs font-bold text-slate-400">
                    {currencySymbol}
                  </span>
                )}
                <input
                  type={
                    field.fieldType === 'number' || field.fieldType === 'currency'
                      ? 'number'
                      : field.fieldType === 'date'
                      ? 'date'
                      : field.fieldType === 'time'
                      ? 'time'
                      : 'text'
                  }
                  value={val}
                  placeholder={`Enter ${field.name.toLowerCase()}...`}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  className={`w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    field.fieldType === 'currency' ? 'pl-7' : ''
                  }`}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
