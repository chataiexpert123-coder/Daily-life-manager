import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Play, Pause, Trash2, Volume2, Sparkles } from 'lucide-react';
import { VoiceNoteItem } from '../../types';

interface VoiceRecorderProps {
  initialVoiceNote?: VoiceNoteItem;
  onSaveVoiceNote: (voiceNote?: VoiceNoteItem) => void;
}

export const VoiceRecorder: React.FC<VoiceRecorderProps> = ({
  initialVoiceNote,
  onSaveVoiceNote,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [voiceNote, setVoiceNote] = useState<VoiceNoteItem | undefined>(initialVoiceNote);
  const [isPlaying, setIsPlaying] = useState(false);
  const [permissionError, setPermissionError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>(initialVoiceNote?.transcript || '');
  const [isTranscribing, setIsTranscribing] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const startRecording = async () => {
    setPermissionError(null);
    audioChunksRef.current = [];
    setTranscript('');

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Audio recording is not supported in this browser environment.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64data = reader.result as string;
          const newVoiceNote: VoiceNoteItem = {
            id: `voice-${Date.now()}`,
            dataUrl: base64data,
            durationSeconds: recordingDuration,
            transcript: transcript,
            recordedAt: new Date().toISOString(),
          };
          setVoiceNote(newVoiceNote);
          onSaveVoiceNote(newVoiceNote);
        };

        // Stop all tracks to release mic
        stream.getTracks().forEach((track) => track.stop());
      };

      // Speech-to-text if available
      // @ts-ignore
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        try {
          const recognition = new SpeechRecognition();
          recognition.continuous = true;
          recognition.interimResults = true;
          recognition.lang = 'en-IN'; // Works great for Indian English / Hinglish
          recognition.onresult = (event: any) => {
            let currentText = '';
            for (let i = 0; i < event.results.length; i++) {
              currentText += event.results[i][0].transcript + ' ';
            }
            setTranscript(currentText.trim());
          };
          recognition.start();
          speechRecognitionRef.current = recognition;
          setIsTranscribing(true);
        } catch (e) {
          console.log('Speech recognition init info:', e);
        }
      }

      mediaRecorder.start(200);
      setIsRecording(true);
      setIsPaused(false);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone error:', err);
      setPermissionError(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'Microphone permission was denied. Please allow microphone access to record voice notes.'
          : err.message || 'Could not access microphone.'
      );
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    }
  };

  const stopRecording = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch (e) {}
      setIsTranscribing(false);
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    setIsPaused(false);
  };

  const togglePlayback = () => {
    if (!voiceNote?.dataUrl) return;

    if (!audioPlayerRef.current) {
      audioPlayerRef.current = new Audio(voiceNote.dataUrl);
      audioPlayerRef.current.onended = () => setIsPlaying(false);
    }

    if (isPlaying) {
      audioPlayerRef.current.pause();
      setIsPlaying(false);
    } else {
      audioPlayerRef.current.src = voiceNote.dataUrl;
      audioPlayerRef.current.play();
      setIsPlaying(true);
    }
  };

  const deleteVoiceNote = () => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current = null;
    }
    setVoiceNote(undefined);
    setTranscript('');
    onSaveVoiceNote(undefined);
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div id="voice_recorder_container" className="bg-slate-50 dark:bg-slate-900/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <Mic className="w-4 h-4 text-rose-500" />
          <span>Voice Note</span>
        </div>
        {voiceNote && (
          <span className="text-[11px] font-medium text-slate-500">
            {formatSeconds(voiceNote.durationSeconds)} duration
          </span>
        )}
      </div>

      {permissionError && (
        <div className="text-xs text-rose-600 bg-rose-50 dark:bg-rose-950/40 p-2.5 rounded-lg mb-2 border border-rose-200 dark:border-rose-900">
          {permissionError}
        </div>
      )}

      {/* Recording State */}
      {isRecording ? (
        <div className="flex flex-col items-center py-2 space-y-3">
          <div className="flex items-center space-x-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600"></span>
            </span>
            <span className="text-sm font-bold text-rose-600 dark:text-rose-400">
              Recording {formatSeconds(recordingDuration)}
            </span>
            {isPaused && <span className="text-xs text-amber-500 font-semibold">(Paused)</span>}
          </div>

          <div className="flex items-center space-x-3">
            {isPaused ? (
              <button
                type="button"
                id="voice_resume_btn"
                onClick={resumeRecording}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-lg hover:bg-slate-300 transition-colors"
              >
                Resume
              </button>
            ) : (
              <button
                type="button"
                id="voice_pause_btn"
                onClick={pauseRecording}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-lg hover:bg-slate-300 transition-colors"
              >
                Pause
              </button>
            )}

            <button
              type="button"
              id="voice_stop_btn"
              onClick={stopRecording}
              className="flex items-center space-x-1.5 px-4 py-1.5 bg-rose-600 text-white text-xs font-bold rounded-lg shadow-sm hover:bg-rose-700 active:scale-95 transition-all"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Stop & Save</span>
            </button>
          </div>

          {transcript && (
            <div className="w-full text-xs text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-800 p-2 rounded border border-slate-200 dark:border-slate-700 max-h-20 overflow-y-auto">
              <span className="font-semibold text-indigo-600 dark:text-indigo-400">Speech transcript: </span>
              {transcript}
            </div>
          )}
        </div>
      ) : voiceNote ? (
        /* Saved Voice Note Player */
        <div className="space-y-2">
          <div className="flex items-center justify-between bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <div className="flex items-center space-x-2.5">
              <button
                type="button"
                id="voice_playback_btn"
                onClick={togglePlayback}
                className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center hover:bg-indigo-700 shadow-sm transition-transform active:scale-95"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>
              <div className="flex flex-col">
                <span className="text-xs font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1">
                  <Volume2 className="w-3 h-3 text-indigo-500" />
                  {isPlaying ? 'Playing...' : 'Voice Recording'}
                </span>
                <span className="text-[10px] text-slate-400">
                  {formatSeconds(voiceNote.durationSeconds)}
                </span>
              </div>
            </div>

            <button
              type="button"
              id="voice_delete_btn"
              onClick={deleteVoiceNote}
              className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"
              title="Delete audio"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          {voiceNote.transcript && (
            <div className="text-[11px] text-slate-600 dark:text-slate-400 bg-white/60 dark:bg-slate-800/60 p-2 rounded border border-slate-200/60 dark:border-slate-700/60">
              <span className="font-semibold text-slate-500 flex items-center gap-1 mb-0.5">
                <Sparkles className="w-3 h-3 text-amber-500" /> Transcript:
              </span>
              {voiceNote.transcript}
            </div>
          )}
        </div>
      ) : (
        /* Record Button Trigger */
        <div className="flex items-center justify-between">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Record quick audio or voice instructions
          </p>
          <button
            type="button"
            id="voice_record_start_btn"
            onClick={startRecording}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 rounded-lg text-xs font-semibold hover:bg-rose-100 active:scale-95 transition-all"
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Record Voice</span>
          </button>
        </div>
      )}
    </div>
  );
};
