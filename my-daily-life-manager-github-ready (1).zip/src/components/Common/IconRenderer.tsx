import React from 'react';
import * as Icons from 'lucide-react';

interface IconRendererProps {
  name?: string;
  className?: string;
  size?: number;
  style?: React.CSSProperties;
}

export const IconRenderer: React.FC<IconRendererProps> = ({
  name = 'Circle',
  className = 'w-5 h-5',
  size,
  style,
}) => {
  // @ts-ignore
  const IconComponent = Icons[name] || (Icons as any)[name.replace(/[-_ ]+(.)/g, (_, c) => c.toUpperCase())] || Icons.Circle;

  return <IconComponent className={className} size={size} style={style} />;
};

export const DynamicIcon = IconRenderer;

export const AVAILABLE_ICONS = [
  'Briefcase',
  'Users',
  'User',
  'Home',
  'TrendingDown',
  'TrendingUp',
  'Receipt',
  'CheckSquare',
  'FileText',
  'Sparkles',
  'Smile',
  'Calendar',
  'Phone',
  'PhoneCall',
  'Video',
  'Building',
  'HelpCircle',
  'Car',
  'Utensils',
  'Navigation',
  'DollarSign',
  'RefreshCw',
  'RotateCcw',
  'HandCoins',
  'PlusCircle',
  'Zap',
  'Smartphone',
  'Wifi',
  'CreditCard',
  'Banknote',
  'Shield',
  'PlaySquare',
  'Key',
  'Bookmark',
  'BookOpen',
  'MapPin',
  'Heart',
  'Wrench',
  'Lightbulb',
  'ShoppingBag',
  'Camera',
  'Mic',
  'Clock',
  'Tag',
  'Layers',
  'Folder',
  'Award',
  'Flame',
  'Compass',
  'Activity',
];

export const AVAILABLE_COLORS = [
  '#3b82f6', // blue
  '#8b5cf6', // purple
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444', // red
  '#059669', // green
  '#ea580c', // orange
  '#0284c7', // sky
  '#6366f1', // indigo
  '#ec4899', // pink
  '#14b8a6', // teal
  '#64748b', // slate
  '#84cc16', // lime
  '#d97706', // yellow-amber
  '#9333ea', // violet
];
