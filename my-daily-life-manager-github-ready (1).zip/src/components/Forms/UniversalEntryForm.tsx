import React, { useState, useEffect } from 'react';
import {
  X,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Bell,
  Clock,
  Tag,
  CheckCircle2,
  DollarSign,
  Briefcase,
  Users,
  User,
  Home as HomeIcon,
  Sparkles,
  Calendar,
  Layers,
} from 'lucide-react';
import {
  UniversalEntry,
  ModuleId,
  CategoryItem,
  PriorityLevel,
  EntryStatus,
  SubtaskItem,
  CustomField,
  ReminderConfig,
} from '../../types';
import { getCategories, getSettings, saveEntry } from '../../services/storage';
import { VoiceRecorder } from '../Common/VoiceRecorder';
import { AttachmentPicker } from '../Common/AttachmentPicker';
import { CustomFieldsRenderer } from '../Common/CustomFieldsRenderer';

interface UniversalEntryFormProps {
  initialEntry?: Partial<UniversalEntry>;
  initialModuleId?: ModuleId;
  isOpen: boolean;
  onClose: () => void;
  onSaved: (entry: UniversalEntry) => void;
}

export const UniversalEntryForm: React.FC<UniversalEntryFormProps> = ({
  initialEntry,
  initialModuleId = 'personal',
  isOpen,
  onClose,
  onSaved,
}) => {
  const settings = getSettings();
  const [moduleId, setModuleId] = useState<ModuleId>(initialEntry?.moduleId || initialModuleId);
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  
  // Core Fields
  const [title, setTitle] = useState(initialEntry?.title || '');
  const [description, setDescription] = useState(initialEntry?.description || '');
  const [date, setDate] = useState(initialEntry?.date || new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState(initialEntry?.time || new Date().toTimeString().slice(0, 5));
  const [categoryId, setCategoryId] = useState<string>(initialEntry?.categoryId || '');
  const [subcategory, setSubcategory] = useState<string>(initialEntry?.subcategory || '');
  const [priority, setPriority] = useState<PriorityLevel>(initialEntry?.priority || 'medium');
  const [status, setStatus] = useState<EntryStatus>(initialEntry?.status || 'pending');
  const [amount, setAmount] = useState<string>(initialEntry?.amount !== undefined ? String(initialEntry.amount) : '');
  const [paymentMode, setPaymentMode] = useState<string>(initialEntry?.paymentMode || 'UPI');
  
  // Additional fields
  const [vendorOrPerson, setVendorOrPerson] = useState(initialEntry?.vendorOrPerson || initialEntry?.person || '');
  const [organization, setOrganization] = useState(initialEntry?.organization || '');
  const [department, setDepartment] = useState(initialEntry?.department || '');
  const [referenceNumber, setReferenceNumber] = useState(initialEntry?.referenceNumber || '');
  const [fileNumber, setFileNumber] = useState(initialEntry?.fileNumber || '');
  const [billNumber, setBillNumber] = useState(initialEntry?.billNumber || '');
  const [gstNumber, setGstNumber] = useState(initialEntry?.gstNumber || '');
  const [dueDate, setDueDate] = useState(initialEntry?.dueDate || '');
  const [location, setLocation] = useState(initialEntry?.location || '');
  
  // Subtasks
  const [subtasks, setSubtasks] = useState<SubtaskItem[]>(initialEntry?.subtasks || []);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  
  // Time blocking
  const [startTime, setStartTime] = useState(initialEntry?.timeBlock?.startTime || '');
  const [endTime, setEndTime] = useState(initialEntry?.timeBlock?.endTime || '');
  
  // Reminders
  const [reminderEnabled, setReminderEnabled] = useState(Boolean(initialEntry?.reminder?.enabled));
  const [reminderOption, setReminderOption] = useState<ReminderConfig['timeOption']>(initialEntry?.reminder?.timeOption || '10m');
  const [reminderRecurring, setReminderRecurring] = useState<ReminderConfig['recurring']>(initialEntry?.reminder?.recurring || 'none');
  
  // Tags
  const [tags, setTags] = useState<string[]>(initialEntry?.tags || []);
  const [tagInput, setTagInput] = useState('');
  
  // Attachments & Voice
  const [attachments, setAttachments] = useState(initialEntry?.attachments || []);
  const [voiceNote, setVoiceNote] = useState(initialEntry?.voiceNote);
  
  // Custom fields
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, any>>(initialEntry?.customFieldValues || {});
  
  // Progressive disclosure
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Load categories when moduleId changes
  useEffect(() => {
    const cats = getCategories(moduleId).filter((c) => !c.isArchived);
    setCategories(cats);
    if (!categoryId || !cats.some((c) => c.id === categoryId)) {
      setCategoryId(cats[0]?.id || '');
      setSubcategory(cats[0]?.subcategories[0] || '');
    }
  }, [moduleId]);

  // Sync subcategory options when categoryId changes
  const activeCategory = categories.find((c) => c.id === categoryId);

  useEffect(() => {
    if (activeCategory && activeCategory.subcategories.length > 0 && !subcategory) {
      setSubcategory(activeCategory.subcategories[0]);
    }
  }, [categoryId, activeCategory]);

  if (!isOpen) return null;

  const isFinancialModule = moduleId === 'expense' || moduleId === 'credit' || moduleId === 'bills' || moduleId === 'wishlist';
  const isTaskModule = moduleId === 'tasks' || moduleId === 'office' || moduleId === 'union';

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim()) return;
    setSubtasks([
      ...subtasks,
      { id: `st-${Date.now()}`, title: newSubtaskTitle.trim(), isCompleted: false },
    ]);
    setNewSubtaskTitle('');
  };

  const handleToggleSubtask = (id: string) => {
    setSubtasks(
      subtasks.map((st) => (st.id === id ? { ...st, isCompleted: !st.isCompleted } : st))
    );
  };

  const handleRemoveSubtask = (id: string) => {
    setSubtasks(subtasks.filter((st) => st.id !== id));
  };

  const handleAddTag = () => {
    const trimmed = tagInput.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags([...tags, trimmed]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (t: string) => {
    setTags(tags.filter((x) => x !== t));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!title.trim()) {
      setValidationError('Please enter a title or activity name.');
      return;
    }

    setIsSubmitting(true);

    try {
      const selectedCat = categories.find((c) => c.id === categoryId);
      
      let entryType = 'General Entry';
      if (moduleId === 'expense') entryType = 'Expense';
      else if (moduleId === 'credit') entryType = 'Credit / Income';
      else if (moduleId === 'bills') entryType = 'Bill';
      else if (moduleId === 'tasks') entryType = 'Task';
      else if (moduleId === 'notes') entryType = 'Note';
      else if (moduleId === 'events') entryType = 'Event';
      else if (moduleId === 'wishlist') entryType = 'Wishlist';
      else if (moduleId === 'office') entryType = 'Office work';
      else if (moduleId === 'union') entryType = 'Union activity';
      else if (moduleId === 'home') entryType = 'Home activity';
      else if (moduleId === 'personal') entryType = 'Personal work';

      const entryData: UniversalEntry = {
        id: initialEntry?.id || `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        moduleId,
        type: initialEntry?.type || entryType,
        title: title.trim(),
        description: description.trim() || undefined,
        date,
        time,
        categoryId: selectedCat?.id || categoryId,
        categoryName: selectedCat?.name || undefined,
        subcategory: subcategory || undefined,
        priority: priority || 'medium',
        status: status || (moduleId === 'bills' ? 'pending' : 'pending'),
        tags,
        amount: amount ? parseFloat(amount) : undefined,
        paymentMode: isFinancialModule || paymentMode ? paymentMode : undefined,
        vendorOrPerson: vendorOrPerson || undefined,
        person: vendorOrPerson || undefined,
        organization: organization || undefined,
        department: department || undefined,
        referenceNumber: referenceNumber || undefined,
        fileNumber: fileNumber || undefined,
        billNumber: billNumber || undefined,
        gstNumber: gstNumber || undefined,
        dueDate: dueDate || (moduleId === 'tasks' ? date : undefined),
        location: location || undefined,
        subtasks: subtasks.length > 0 ? subtasks : undefined,
        timeBlock: startTime && endTime ? { startTime, endTime } : undefined,
        reminder: reminderEnabled
          ? {
              enabled: true,
              timeOption: reminderOption,
              recurring: reminderRecurring,
              triggered: false,
            }
          : undefined,
        attachments,
        voiceNote,
        customFieldValues: Object.keys(customFieldValues).length > 0 ? customFieldValues : undefined,
        isArchived: Boolean(initialEntry?.isArchived),
        createdAt: initialEntry?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const saved = saveEntry(entryData);
      onSaved(saved);
      onClose();
    } catch (err: any) {
      setValidationError(err.message || 'Failed to save entry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const moduleCustomFields = settings.customFields.filter(
    (cf) => cf.moduleId === moduleId || !cf.moduleId
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end sm:items-center justify-center sm:p-4 overflow-y-auto">
      <div
        id="universal_entry_modal"
        className="bg-white dark:bg-slate-900 w-full sm:max-w-xl max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse" />
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              {initialEntry?.id ? 'Edit Entry' : 'Quick Add Entry'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {validationError && (
            <div className="text-xs text-rose-600 bg-rose-50 dark:bg-rose-950/40 p-3 rounded-xl border border-rose-200 dark:border-rose-900">
              {validationError}
            </div>
          )}

          {/* Module Type Selector Pills */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold tracking-wider uppercase text-slate-400 dark:text-slate-500">
              Type / Module
            </label>
            <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'office', label: 'Office', icon: Briefcase, color: 'text-blue-500' },
                { id: 'union', label: 'Union', icon: Users, color: 'text-purple-500' },
                { id: 'personal', label: 'Personal', icon: User, color: 'text-emerald-500' },
                { id: 'home', label: 'Home', icon: HomeIcon, color: 'text-amber-500' },
                { id: 'expense', label: 'Expense', icon: DollarSign, color: 'text-red-500' },
                { id: 'credit', label: 'Credit', icon: DollarSign, color: 'text-green-500' },
                { id: 'bills', label: 'Bill', icon: Layers, color: 'text-orange-500' },
                { id: 'tasks', label: 'Task', icon: CheckCircle2, color: 'text-sky-500' },
                { id: 'notes', label: 'Note', icon: Sparkles, color: 'text-indigo-500' },
                { id: 'events', label: 'Event', icon: Calendar, color: 'text-teal-500' },
              ].map((tab) => {
                const isSelected = moduleId === tab.id;
                const IconComp = tab.icon;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setModuleId(tab.id as ModuleId)}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                      isSelected
                        ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-sm scale-105'
                        : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    <IconComp className={`w-3.5 h-3.5 ${tab.color}`} />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Core Title Field */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              {moduleId === 'expense'
                ? 'Expense Title / Item *'
                : moduleId === 'credit'
                ? 'Income / Source Title *'
                : moduleId === 'bills'
                ? 'Bill Name *'
                : moduleId === 'tasks'
                ? 'Task Title *'
                : 'Activity / Title *'}
            </label>
            <input
              type="text"
              required
              autoFocus
              id="entry_title_input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                moduleId === 'expense'
                  ? 'e.g., Office printing, Fuel, Lunch'
                  : moduleId === 'tasks'
                  ? 'e.g., Submit representation, Prepare audit file'
                  : moduleId === 'bills'
                  ? 'e.g., Electricity bill, Mobile recharge'
                  : 'e.g., Member meeting, Follow-up call'
              }
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
            />
          </div>

          {/* Amount Field (Financial) */}
          {isFinancialModule && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <span>Amount ({settings.currencySymbol}) *</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-sm font-bold text-slate-500">
                    {settings.currencySymbol}
                  </span>
                  <input
                    type="number"
                    step="any"
                    required
                    id="entry_amount_input"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full pl-8 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Payment Mode
                </label>
                <select
                  id="entry_payment_mode_select"
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {settings.defaultPaymentModes.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Category & Subcategory Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Category
              </label>
              <select
                id="entry_category_select"
                value={categoryId}
                onChange={(e) => {
                  setCategoryId(e.target.value);
                  const found = categories.find((c) => c.id === e.target.value);
                  if (found && found.subcategories.length > 0) {
                    setSubcategory(found.subcategories[0]);
                  } else {
                    setSubcategory('');
                  }
                }}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            {activeCategory && activeCategory.subcategories.length > 0 && (
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Subcategory
                </label>
                <select
                  id="entry_subcategory_select"
                  value={subcategory}
                  onChange={(e) => setSubcategory(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">None / General</option>
                  {activeCategory.subcategories.map((sub) => (
                    <option key={sub} value={sub}>
                      {sub}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Date & Time Row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Date
              </label>
              <input
                type="date"
                required
                id="entry_date_input"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Time
              </label>
              <input
                type="time"
                id="entry_time_input"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Task/Priority specifics */}
          {isTaskModule && (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Priority
                </label>
                <select
                  id="entry_priority_select"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {settings.defaultPriorities.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Status
                </label>
                <select
                  id="entry_status_select"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as EntryStatus)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {settings.defaultStatuses.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Quick Description */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Description / Notes
            </label>
            <textarea
              rows={2}
              id="entry_description_input"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details, observations, or action points..."
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Progressive Disclosure Toggle */}
          <div className="pt-1">
            <button
              type="button"
              id="more_options_toggle_btn"
              onClick={() => setShowMoreOptions(!showMoreOptions)}
              className="w-full flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/70 hover:bg-slate-200/80 dark:hover:bg-slate-800 rounded-xl text-xs font-semibold text-indigo-600 dark:text-indigo-400 transition-colors"
            >
              <span>
                {showMoreOptions ? 'Hide Advanced Options' : '+ MORE OPTIONS (Voice, Photos, Checklist, Reminders, Custom Fields)'}
              </span>
              {showMoreOptions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {/* Expandable Advanced Fields */}
          {showMoreOptions && (
            <div className="space-y-4 pt-2 border-t border-slate-200 dark:border-slate-800 animate-in fade-in duration-150">
              {/* Module-Specific Extra Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(moduleId === 'office' || moduleId === 'union' || moduleId === 'personal') && (
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Person Involved / Employee
                    </label>
                    <input
                      type="text"
                      value={vendorOrPerson}
                      onChange={(e) => setVendorOrPerson(e.target.value)}
                      placeholder="Name / Designation"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                )}

                {moduleId === 'office' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Department
                      </label>
                      <input
                        type="text"
                        value={department}
                        onChange={(e) => setDepartment(e.target.value)}
                        placeholder="e.g., Administration, HR, Finance"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Reference Number
                      </label>
                      <input
                        type="text"
                        value={referenceNumber}
                        onChange={(e) => setReferenceNumber(e.target.value)}
                        placeholder="e.g., REF/2026/09"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        File Number
                      </label>
                      <input
                        type="text"
                        value={fileNumber}
                        onChange={(e) => setFileNumber(e.target.value)}
                        placeholder="e.g., FILE-401"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </>
                )}

                {moduleId === 'union' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Union / Organization
                      </label>
                      <input
                        type="text"
                        value={organization}
                        onChange={(e) => setOrganization(e.target.value)}
                        placeholder="e.g., Welfare Union"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Letter / Ref Number
                      </label>
                      <input
                        type="text"
                        value={referenceNumber}
                        onChange={(e) => setReferenceNumber(e.target.value)}
                        placeholder="e.g., UN/LTR/2026/04"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </>
                )}

                {(moduleId === 'expense' || moduleId === 'bills') && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Vendor / Provider
                      </label>
                      <input
                        type="text"
                        value={vendorOrPerson}
                        onChange={(e) => setVendorOrPerson(e.target.value)}
                        placeholder="e.g., Sai Xerox, Airtel, Landlord"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Bill / Invoice Number
                      </label>
                      <input
                        type="text"
                        value={billNumber}
                        onChange={(e) => setBillNumber(e.target.value)}
                        placeholder="e.g., INV-892"
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </>
                )}

                {moduleId === 'events' && (
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Location / Venue
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g., Central Town Hall, Office Conf Room"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                )}
              </div>

              {/* Time Blocking Row */}
              <div className="space-y-1.5 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="flex items-center space-x-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Time Blocking / Timeline Slot</span>
                </div>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="text-[11px] text-slate-500">Start Time</label>
                    <input
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500">End Time</label>
                    <input
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* Subtasks / Checklist */}
              <div className="space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Checklist & Subtasks</span>
                    {subtasks.length > 0 && (
                      <span className="text-[11px] font-normal text-slate-400">
                        ({subtasks.filter((s) => s.isCompleted).length}/{subtasks.length} done)
                      </span>
                    )}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={newSubtaskTitle}
                    onChange={(e) => setNewSubtaskTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSubtask();
                      }
                    }}
                    placeholder="Add subtask item..."
                    className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddSubtask}
                    className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-semibold hover:bg-indigo-700 active:scale-95"
                  >
                    Add
                  </button>
                </div>

                {subtasks.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    {subtasks.map((st) => (
                      <div
                        key={st.id}
                        className="flex items-center justify-between bg-white dark:bg-slate-800 p-2 rounded-lg border border-slate-200 dark:border-slate-700"
                      >
                        <label className="flex items-center space-x-2 cursor-pointer flex-1 mr-2">
                          <input
                            type="checkbox"
                            checked={st.isCompleted}
                            onChange={() => handleToggleSubtask(st.id)}
                            className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                          />
                          <span
                            className={`text-xs ${
                              st.isCompleted
                                ? 'line-through text-slate-400 dark:text-slate-500'
                                : 'text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {st.title}
                          </span>
                        </label>
                        <button
                          type="button"
                          onClick={() => handleRemoveSubtask(st.id)}
                          className="text-slate-400 hover:text-rose-500 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Reminders Section */}
              <div className="space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={reminderEnabled}
                    onChange={(e) => setReminderEnabled(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                  />
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Bell className="w-3.5 h-3.5 text-amber-500" />
                    <span>Set Reminder / Alarm</span>
                  </span>
                </label>

                {reminderEnabled && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1.5 pl-6">
                    <div>
                      <label className="text-[11px] text-slate-500 font-medium">When to notify</label>
                      <select
                        value={reminderOption}
                        onChange={(e) => setReminderOption(e.target.value as any)}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                      >
                        <option value="exact">At exact time</option>
                        <option value="5m">5 minutes before</option>
                        <option value="10m">10 minutes before</option>
                        <option value="30m">30 minutes before</option>
                        <option value="1h">1 hour before</option>
                        <option value="1d">1 day before</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-500 font-medium">Recurring</label>
                      <select
                        value={reminderRecurring}
                        onChange={(e) => setReminderRecurring(e.target.value as any)}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                      >
                        <option value="none">No Repeat (Once)</option>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              {/* Voice Recording */}
              <VoiceRecorder
                initialVoiceNote={voiceNote}
                onSaveVoiceNote={(vn) => setVoiceNote(vn)}
              />

              {/* Photos & Documents */}
              <AttachmentPicker
                attachments={attachments}
                onChange={(atts) => setAttachments(atts)}
              />

              {/* Tags */}
              <div className="space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Tags</span>
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddTag();
                      }
                    }}
                    placeholder="Type tag and press Enter..."
                    className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold"
                  >
                    Add
                  </button>
                </div>
                {tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {tags.map((t) => (
                      <span
                        key={t}
                        className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300"
                      >
                        #{t}
                        <button
                          type="button"
                          onClick={() => handleRemoveTag(t)}
                          className="ml-1 text-indigo-400 hover:text-indigo-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Dynamic Custom Fields */}
              {moduleCustomFields.length > 0 && (
                <CustomFieldsRenderer
                  customFields={moduleCustomFields}
                  values={customFieldValues}
                  onChange={setCustomFieldValues}
                  currencySymbol={settings.currencySymbol}
                />
              )}
            </div>
          )}

          {/* Form Actions Footer */}
          <div className="sticky bottom-0 bg-white dark:bg-slate-900 pt-3 pb-1 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end space-x-2.5">
            <button
              type="button"
              id="entry_cancel_btn"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="entry_save_btn"
              disabled={isSubmitting}
              className="px-6 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-95 rounded-xl shadow-md shadow-indigo-500/20 transition-all flex items-center space-x-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{initialEntry?.id ? 'Update Record' : 'Save Entry'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
