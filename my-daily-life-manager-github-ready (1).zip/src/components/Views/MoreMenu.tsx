import React from 'react';
import {
  BookOpen,
  Gift,
  FileText,
  Calendar,
  Smile,
  BarChart3,
  Sliders,
  FileSpreadsheet,
  HardDrive,
  Settings as SettingsIcon,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { getEntries } from '../../services/storage';

interface MoreMenuProps {
  onSelectOption: (optionId: string) => void;
}

export const MoreMenu: React.FC<MoreMenuProps> = ({ onSelectOption }) => {
  const entries = getEntries();
  const notesCount = entries.filter((e) => e.moduleId === 'notes' || e.type === 'Note').length;
  const eventsCount = entries.filter((e) => e.moduleId === 'events' || e.type === 'Event').length;
  const wishlistCount = entries.filter((e) => e.moduleId === 'wishlist' || e.type === 'Wishlist').length;

  const MENU_SECTIONS = [
    {
      title: 'Personal & Journaling',
      items: [
        { id: 'diary', label: 'Daily Diary & Reflection', icon: BookOpen, color: 'bg-indigo-600', desc: 'Daily thoughts, mood, highlights & gratitude' },
        { id: 'wishlist', label: 'Goals & Wishlist', icon: Gift, color: 'bg-pink-600', badge: wishlistCount > 0 ? String(wishlistCount) : undefined, desc: 'Target items, planning & achievements' },
        { id: 'affirmations', label: 'Daily Affirmations', icon: Smile, color: 'bg-amber-500', desc: 'English, Hindi & Gujarati motivation' },
      ],
    },
    {
      title: 'Productivity & Records',
      items: [
        { id: 'notes', label: 'Notes & Ideas', icon: FileText, color: 'bg-blue-600', badge: notesCount > 0 ? String(notesCount) : undefined, desc: 'Quick memos, thoughts & observations' },
        { id: 'events', label: 'Events & Meetings', icon: Calendar, color: 'bg-teal-600', badge: eventsCount > 0 ? String(eventsCount) : undefined, desc: 'Hearings, appointments & conferences' },
        { id: 'analytics', label: 'Productivity Analytics', icon: BarChart3, color: 'bg-purple-600', desc: 'Trends, category summaries & completion metrics' },
      ],
    },
    {
      title: 'Customization & Data Management',
      items: [
        { id: 'customize', label: 'Customize Categories & Fields', icon: Sliders, color: 'bg-emerald-600', desc: 'Add new categories, subcategories & custom fields' },
        { id: 'sheets', label: 'Google Sheets Real-Time Sync', icon: FileSpreadsheet, color: 'bg-green-600', desc: 'Sync all entries to your Google Sheet automatically' },
        { id: 'backup', label: 'Backup & Restore', icon: HardDrive, color: 'bg-sky-600', desc: 'Download JSON backup or restore past data' },
        { id: 'settings', label: 'App Settings & Language', icon: SettingsIcon, color: 'bg-slate-700', desc: 'Theme, currency symbol, default priorities' },
      ],
    },
  ];

  return (
    <div id="more_menu_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      <div>
        <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
          <span>More Features & Tools</span>
        </h2>
        <p className="text-xs text-slate-500">
          Access specialized modules, diary reflections, analytics, and settings
        </p>
      </div>

      <div className="space-y-4">
        {MENU_SECTIONS.map((section) => (
          <div key={section.title} className="space-y-2">
            <span className="text-[11px] font-bold tracking-wider uppercase text-slate-400 dark:text-slate-500 px-1">
              {section.title}
            </span>

            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800/80 overflow-hidden shadow-xs">
              {section.items.map((item) => {
                const IconComp = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    id={`more_opt_${item.id}`}
                    onClick={() => onSelectOption(item.id)}
                    className="w-full flex items-center justify-between p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors text-left group"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-9 h-9 rounded-xl ${item.color} text-white flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform`}>
                        <IconComp className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 transition-colors">
                          {item.label}
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          {item.desc}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {item.badge && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                          {item.badge}
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transform group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
