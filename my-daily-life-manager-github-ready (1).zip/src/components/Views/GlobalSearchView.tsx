import React, { useState, useMemo } from 'react';
import { Search, X, Calendar, DollarSign, Tag, User, Building, FileText, ArrowRight } from 'lucide-react';
import { UniversalEntry } from '../../types';
import { getEntries } from '../../services/storage';

interface GlobalSearchViewProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectEntry: (entry: UniversalEntry) => void;
}

export const GlobalSearchView: React.FC<GlobalSearchViewProps> = ({
  isOpen,
  onClose,
  onSelectEntry,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterModule, setFilterModule] = useState<string>('all');
  const entries = getEntries();

  const searchResults = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return [];

    return entries.filter((entry) => {
      if (filterModule !== 'all' && entry.moduleId !== filterModule) return false;

      const titleMatch = entry.title.toLowerCase().includes(query);
      const descMatch = (entry.description || '').toLowerCase().includes(query);
      const catMatch = (entry.categoryName || '').toLowerCase().includes(query);
      const subcatMatch = (entry.subcategory || '').toLowerCase().includes(query);
      const personMatch = (entry.vendorOrPerson || entry.person || '').toLowerCase().includes(query);
      const orgMatch = (entry.organization || '').toLowerCase().includes(query);
      const refMatch = (entry.referenceNumber || entry.fileNumber || entry.billNumber || '').toLowerCase().includes(query);
      const tagMatch = (entry.tags || []).some((t) => t.toLowerCase().includes(query));
      const amountMatch = entry.amount !== undefined && String(entry.amount).includes(query);
      const dateMatch = entry.date.includes(query);

      return (
        titleMatch ||
        descMatch ||
        catMatch ||
        subcatMatch ||
        personMatch ||
        orgMatch ||
        refMatch ||
        tagMatch ||
        amountMatch ||
        dateMatch
      );
    });
  }, [searchQuery, filterModule, entries]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-start justify-center p-3 sm:p-6 overflow-y-auto">
      <div
        id="global_search_modal"
        className="bg-white dark:bg-slate-900 max-w-2xl w-full rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150 mt-4"
      >
        {/* Search Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center space-x-3">
            <Search className="w-5 h-5 text-indigo-500" />
            <input
              type="text"
              autoFocus
              id="global_search_input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, person, organization, tags, ref number, or amounts..."
              className="flex-1 text-sm font-medium bg-transparent text-slate-900 dark:text-slate-100 focus:outline-none placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Module Filter Chips */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
            {['all', 'office', 'union', 'personal', 'home', 'expense', 'credit', 'bills', 'tasks', 'notes', 'events'].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setFilterModule(m)}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap capitalize transition-colors ${
                  filterModule === m
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                {m === 'all' ? 'All Modules' : m}
              </button>
            ))}
          </div>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {!searchQuery.trim() ? (
            <div className="text-center py-12 text-slate-400 dark:text-slate-500">
              <Search className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-xs">Type anything to search across all office, union, personal, financial and task records</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="text-center py-12 text-slate-400 dark:text-slate-500">
              <p className="text-xs">No records found matching "{searchQuery}"</p>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="text-[11px] font-semibold text-slate-500">
                Found {searchResults.length} records
              </div>
              {searchResults.map((entry) => (
                <div
                  key={entry.id}
                  onClick={() => {
                    onSelectEntry(entry);
                    onClose();
                  }}
                  className="p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50/60 dark:hover:bg-indigo-950/40 rounded-xl border border-slate-200/80 dark:border-slate-700/80 cursor-pointer transition-all flex items-start justify-between group"
                >
                  <div className="space-y-1 flex-1 pr-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                        {entry.moduleId}
                      </span>
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 transition-colors">
                        {entry.title}
                      </span>
                    </div>

                    {entry.description && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                        {entry.description}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-slate-500 pt-0.5">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {entry.date} {entry.time}
                      </span>
                      {entry.categoryName && (
                        <span className="font-medium text-slate-600 dark:text-slate-400">
                          • {entry.categoryName}
                        </span>
                      )}
                      {(entry.vendorOrPerson || entry.person) && (
                        <span className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                          <User className="w-3 h-3 text-slate-400" />
                          {entry.vendorOrPerson || entry.person}
                        </span>
                      )}
                      {entry.amount !== undefined && (
                        <span className="font-bold text-rose-600 dark:text-rose-400">
                          ₹{entry.amount}
                        </span>
                      )}
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transform group-hover:translate-x-0.5 transition-transform" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
