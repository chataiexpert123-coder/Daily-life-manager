import React, { useState } from 'react';
import {
  X,
  Calendar,
  Clock,
  Tag,
  User,
  Building,
  DollarSign,
  Briefcase,
  Users,
  Home as HomeIcon,
  CheckCircle2,
  Trash2,
  Edit2,
  Copy,
  Paperclip,
  Volume2,
  Share2,
  Sparkles,
  MapPin,
  Bell,
  Play,
  Pause,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UniversalEntry } from '../../types';
import { deleteEntry, saveEntry, getSettings } from '../../services/storage';
import { UniversalEntryForm } from '../Forms/UniversalEntryForm';

interface EntryDetailModalProps {
  entry: UniversalEntry | null;
  isOpen: boolean;
  onClose: () => void;
  onEntryUpdated: () => void;
}

export const EntryDetailModal: React.FC<EntryDetailModalProps> = ({
  entry,
  isOpen,
  onClose,
  onEntryUpdated,
}) => {
  const settings = getSettings();
  const [isEditing, setIsEditing] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  if (!isOpen || !entry) return null;

  const handleDelete = () => {
    if (window.confirm(`Delete entry "${entry.title}"?`)) {
      deleteEntry(entry.id);
      onEntryUpdated();
      onClose();
    }
  };

  const handleDuplicate = () => {
    const duplicated: UniversalEntry = {
      ...entry,
      id: `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      title: `${entry.title} (Copy)`,
      date: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveEntry(duplicated);
    onEntryUpdated();
    onClose();
  };

  const handleToggleSubtask = (subtaskId: string) => {
    const updatedSubtasks = (entry.subtasks || []).map((s) =>
      s.id === subtaskId ? { ...s, isCompleted: !s.isCompleted } : s
    );
    const allDone = updatedSubtasks.length > 0 && updatedSubtasks.every((s) => s.isCompleted);
    saveEntry({
      ...entry,
      subtasks: updatedSubtasks,
      status: allDone ? 'completed' : entry.status,
    });
    onEntryUpdated();
  };

  const togglePlayVoice = () => {
    if (!entry.voiceNote?.dataUrl) return;

    if (!audioElement) {
      const audio = new Audio(entry.voiceNote.dataUrl);
      audio.onended = () => setIsPlayingAudio(false);
      setAudioElement(audio);
      audio.play();
      setIsPlayingAudio(true);
    } else {
      if (isPlayingAudio) {
        audioElement.pause();
        setIsPlayingAudio(false);
      } else {
        audioElement.play();
        setIsPlayingAudio(true);
      }
    }
  };

  if (isEditing) {
    return (
      <UniversalEntryForm
        isOpen={true}
        initialEntry={entry}
        initialModuleId={entry.moduleId}
        onClose={() => setIsEditing(false)}
        onSaved={(updated) => {
          setIsEditing(false);
          onEntryUpdated();
          onClose();
        }}
      />
    );
  }

  const isCredit = entry.moduleId === 'credit' || entry.type === 'Credit / Income';

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end sm:items-center justify-center sm:p-4 overflow-y-auto">
      <div
        id="entry_detail_modal"
        className="bg-white dark:bg-slate-900 w-full sm:max-w-xl max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
              {entry.moduleId}
            </span>
            <span className="text-xs font-semibold text-slate-500">
              {entry.type}
            </span>
          </div>

          <div className="flex items-center space-x-1">
            <button
              type="button"
              id="detail_duplicate_btn"
              onClick={handleDuplicate}
              className="p-2 rounded-xl text-slate-500 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              title="Duplicate"
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              type="button"
              id="detail_edit_btn"
              onClick={() => setIsEditing(true)}
              className="p-2 rounded-xl text-slate-500 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              title="Edit"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              id="detail_delete_btn"
              onClick={handleDelete}
              className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              title="Delete"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Title & Amount */}
          <div className="flex items-start justify-between gap-3">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 leading-snug">
              {entry.title}
            </h2>
            {entry.amount !== undefined && (
              <span
                className={`text-lg font-black whitespace-nowrap ${
                  isCredit ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {isCredit ? '+' : '-'}{settings.currencySymbol}{entry.amount.toLocaleString()}
              </span>
            )}
          </div>

          {/* Key metadata grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 font-medium">Date & Time</span>
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                {entry.date} {entry.time}
              </p>
            </div>

            {entry.categoryName && (
              <div>
                <span className="text-[10px] text-slate-400 font-medium">Category</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {entry.categoryName} {entry.subcategory ? `(${entry.subcategory})` : ''}
                </p>
              </div>
            )}

            {entry.priority && (
              <div>
                <span className="text-[10px] text-slate-400 font-medium">Priority</span>
                <p className="font-bold uppercase text-slate-800 dark:text-slate-200">
                  {entry.priority}
                </p>
              </div>
            )}

            {entry.status && (
              <div>
                <span className="text-[10px] text-slate-400 font-medium">Status</span>
                <p className="font-bold capitalize text-slate-800 dark:text-slate-200">
                  {entry.status.replace('_', ' ')}
                </p>
              </div>
            )}

            {entry.paymentMode && (
              <div>
                <span className="text-[10px] text-slate-400 font-medium">Payment Mode</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {entry.paymentMode}
                </p>
              </div>
            )}

            {entry.dueDate && (
              <div>
                <span className="text-[10px] text-slate-400 font-medium">Due Date</span>
                <p className="font-bold text-orange-600 dark:text-orange-400">
                  {entry.dueDate}
                </p>
              </div>
            )}
          </div>

          {/* Description */}
          {entry.description && (
            <div className="space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Details / Notes
              </span>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed bg-slate-50 dark:bg-slate-800/30 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                {entry.description}
              </p>
            </div>
          )}

          {/* Extra Context Info (Person, Department, Org, Ref No, Bill No) */}
          {(entry.vendorOrPerson || entry.person || entry.department || entry.organization || entry.referenceNumber || entry.billNumber || entry.location) && (
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Entity & References
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {(entry.vendorOrPerson || entry.person) && (
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Person / Vendor</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {entry.vendorOrPerson || entry.person}
                    </p>
                  </div>
                )}
                {entry.department && (
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Department</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {entry.department}
                    </p>
                  </div>
                )}
                {entry.organization && (
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Organization</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {entry.organization}
                    </p>
                  </div>
                )}
                {entry.referenceNumber && (
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Reference No.</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {entry.referenceNumber}
                    </p>
                  </div>
                )}
                {entry.billNumber && (
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Bill / Inv No.</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {entry.billNumber}
                    </p>
                  </div>
                )}
                {entry.location && (
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Location</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {entry.location}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Subtasks Checklist */}
          {entry.subtasks && entry.subtasks.length > 0 && (
            <div className="space-y-2 pt-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>Checklist & Subtasks</span>
                <span className="text-slate-500">
                  {entry.subtasks.filter((s) => s.isCompleted).length}/{entry.subtasks.length} Done
                </span>
              </span>
              <div className="space-y-1.5">
                {entry.subtasks.map((st) => (
                  <label
                    key={st.id}
                    className="flex items-center space-x-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={st.isCompleted}
                      onChange={() => handleToggleSubtask(st.id)}
                      className="w-4 h-4 text-indigo-600 rounded"
                    />
                    <span className={`text-xs ${st.isCompleted ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                      {st.title}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Voice Recording Player */}
          {entry.voiceNote && (
            <div className="space-y-2 bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-rose-500" />
                  <span>Voice Note Recording ({entry.voiceNote.durationSeconds}s)</span>
                </span>
                <button
                  type="button"
                  onClick={togglePlayVoice}
                  className="px-3 py-1 bg-indigo-600 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                >
                  {isPlayingAudio ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlayingAudio ? 'Pause' : 'Play Audio'}</span>
                </button>
              </div>

              {entry.voiceNote.transcript && (
                <div className="text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700">
                  <strong className="text-indigo-600 dark:text-indigo-400">Transcript: </strong>
                  {entry.voiceNote.transcript}
                </div>
              )}
            </div>
          )}

          {/* Photos and Attachments Grid */}
          {entry.attachments && entry.attachments.length > 0 && (
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Paperclip className="w-3.5 h-3.5" />
                <span>Attachments ({entry.attachments.length})</span>
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {entry.attachments.map((att) => (
                  <div
                    key={att.id}
                    className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 aspect-video flex items-center justify-center p-1"
                  >
                    {att.type === 'image' && att.dataUrl ? (
                      <img
                        src={att.dataUrl}
                        alt={att.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    ) : (
                      <a
                        href={att.dataUrl}
                        download={att.name}
                        className="text-[11px] text-indigo-600 hover:underline text-center p-2 truncate"
                      >
                        {att.name}
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tags */}
          {entry.tags && entry.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {entry.tags.map((t) => (
                <span
                  key={t}
                  className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  #{t}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
