import React, { useMemo } from 'react';
import { BarChart3, TrendingUp, TrendingDown, CheckCircle2, Calendar, PieChart, Layers } from 'lucide-react';
import { UniversalEntry } from '../../types';
import { getEntries, getSettings } from '../../services/storage';

export const AnalyticsView: React.FC = () => {
  const settings = getSettings();
  const entries = getEntries().filter((e) => !e.isArchived);

  // Module distribution
  const moduleCounts = useMemo(() => {
    const map: Record<string, number> = {};
    entries.forEach((e) => {
      map[e.moduleId] = (map[e.moduleId] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [entries]);

  // Tasks completed vs pending
  const tasks = entries.filter((e) => e.moduleId === 'tasks' || e.type === 'Task');
  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const pendingTasks = tasks.filter((t) => t.status !== 'completed').length;
  const taskCompletionRate = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

  // Monthly Financials
  const monthlyExpenses = entries
    .filter((e) => e.moduleId === 'expense' || e.type === 'Expense')
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const monthlyCredits = entries
    .filter((e) => e.moduleId === 'credit' || e.type === 'Credit / Income')
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  return (
    <div id="analytics_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      <div>
        <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
          <BarChart3 className="w-5 h-5 text-indigo-600" />
          <span>Productivity & Activity Analytics</span>
        </h2>
        <p className="text-xs text-slate-500">
          Insights into your tasks, finances, and daily records
        </p>
      </div>

      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-500 uppercase">Total Records</span>
          <p className="text-xl font-black text-slate-900 dark:text-slate-100">{entries.length}</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-emerald-600 uppercase">Task Completion</span>
          <p className="text-xl font-black text-emerald-600">{taskCompletionRate}%</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-rose-600 uppercase">Expenses</span>
          <p className="text-base sm:text-lg font-black text-rose-600">{settings.currencySymbol}{monthlyExpenses.toLocaleString()}</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-indigo-600 uppercase">Income / Credits</span>
          <p className="text-base sm:text-lg font-black text-indigo-600">{settings.currencySymbol}{monthlyCredits.toLocaleString()}</p>
        </div>
      </div>

      {/* Module Activity Distribution */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <span className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-indigo-500" />
          <span>Activity Records by Module</span>
        </span>

        <div className="space-y-2.5">
          {moduleCounts.map(([mod, count]) => {
            const pct = entries.length > 0 ? Math.round((count / entries.length) * 100) : 0;
            return (
              <div key={mod} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300">
                  <span className="capitalize">{mod}</span>
                  <span className="font-bold">{count} ({pct}%)</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
