import React, { useState, useMemo } from 'react';
import { Sparkles, Plus, CheckCircle2, Calendar, DollarSign, Tag, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';
import { UniversalEntry } from '../../types';
import { getEntries, saveEntry, getSettings } from '../../services/storage';

interface WishlistViewProps {
  onOpenAddWishlist: () => void;
  onSelectEntry: (entry: UniversalEntry) => void;
}

export const WishlistView: React.FC<WishlistViewProps> = ({
  onOpenAddWishlist,
  onSelectEntry,
}) => {
  const settings = getSettings();
  const [entries, setEntries] = useState<UniversalEntry[]>(getEntries());
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');

  const reload = () => setEntries(getEntries());

  const wishlistItems = useMemo(() => {
    return entries.filter((e) => (e.moduleId === 'wishlist' || e.type === 'Wishlist') && !e.isArchived);
  }, [entries]);

  const filteredItems = useMemo(() => {
    if (filter === 'pending') return wishlistItems.filter((i) => i.status !== 'completed');
    if (filter === 'completed') return wishlistItems.filter((i) => i.status === 'completed');
    return wishlistItems;
  }, [wishlistItems, filter]);

  const totalEstimatedCost = wishlistItems
    .filter((i) => i.status !== 'completed')
    .reduce((sum, i) => sum + (i.amount || 0), 0);

  const handleToggleAchieved = (e: React.MouseEvent, item: UniversalEntry) => {
    e.stopPropagation();
    const isDone = item.status === 'completed';
    saveEntry({
      ...item,
      status: isDone ? 'pending' : 'completed',
    });
    reload();

    if (!isDone) {
      confetti({
        particleCount: 60,
        spread: 80,
        origin: { y: 0.7 },
      });
    }
  };

  return (
    <div id="wishlist_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <Gift className="w-5 h-5 text-indigo-600" />
            <span>Goals & Wishlist</span>
          </h2>
          <p className="text-xs text-slate-500">
            Estimated Pending Goals: <span className="font-bold text-indigo-600 dark:text-indigo-400">{settings.currencySymbol}{totalEstimatedCost.toLocaleString()}</span>
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenAddWishlist}
          className="px-3.5 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-indigo-700 active:scale-95 flex items-center gap-1"
        >
          <Plus className="w-4 h-4" />
          <span>Add Goal / Wish</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-1.5 text-xs">
        {[
          { id: 'pending', label: 'Active Wishlist' },
          { id: 'completed', label: 'Achieved 🎉' },
          { id: 'all', label: 'All Items' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id as any)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
              filter === tab.id
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Wishlist Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredItems.length === 0 ? (
          <div className="sm:col-span-2 text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-slate-400 text-xs">
            No wishlist items found. Tap 'Add Goal / Wish' to start planning your aspirations!
          </div>
        ) : (
          filteredItems.map((item) => {
            const isAchieved = item.status === 'completed';
            return (
              <div
                key={item.id}
                onClick={() => onSelectEntry(item)}
                className={`p-4 rounded-2xl border bg-white dark:bg-slate-900 transition-all cursor-pointer flex flex-col justify-between ${
                  isAchieved
                    ? 'border-slate-200 dark:border-slate-800 opacity-60'
                    : 'border-slate-200/80 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 shadow-xs'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-slate-100 flex-1 pr-2">
                      {item.title}
                    </span>
                    {item.amount !== undefined && (
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                        {settings.currencySymbol}{item.amount.toLocaleString()}
                      </span>
                    )}
                  </div>

                  {item.description && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                      {item.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2 text-[10px] text-slate-400">
                    {item.dueDate && <span>Target: {item.dueDate}</span>}
                    {item.categoryName && <span>• {item.categoryName}</span>}
                  </div>

                  <button
                    type="button"
                    onClick={(e) => handleToggleAchieved(e, item)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                      isAchieved
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 hover:bg-indigo-100'
                    }`}
                  >
                    {isAchieved ? 'Achieved ✓' : 'Mark Achieved'}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
