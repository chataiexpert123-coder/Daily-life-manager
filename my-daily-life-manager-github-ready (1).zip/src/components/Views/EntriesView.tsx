import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Calendar,
  Layers,
  ChevronDown,
  Trash2,
  Copy,
  Edit,
  Paperclip,
  Volume2,
  CheckCircle2,
  Plus,
  FileSpreadsheet,
  FileText,
  SlidersHorizontal,
} from 'lucide-react';
import {
  UniversalEntry,
  ModuleId,
  PriorityLevel,
  EntryStatus,
} from '../../types';
import {
  getEntries,
  deleteEntry,
  saveEntry,
  getSettings,
  getCategories,
} from '../../services/storage';
import { exportEntriesToExcel, exportEntriesToCSV } from '../../services/storage';

interface EntriesViewProps {
  onOpenAddModal: (moduleId?: ModuleId) => void;
  onSelectEntry: (entry: UniversalEntry) => void;
}

export const EntriesView: React.FC<EntriesViewProps> = ({
  onOpenAddModal,
  onSelectEntry,
}) => {
  const settings = getSettings();
  const [entries, setEntries] = useState<UniversalEntry[]>(getEntries());
  const [selectedModule, setSelectedModule] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'yesterday' | 'week' | 'month' | 'custom'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  // Reload entries
  const reload = () => setEntries(getEntries());

  const categories = useMemo(() => {
    return getCategories();
  }, []);

  // Filter logic
  const filteredEntries = useMemo(() => {
    return entries.filter((item) => {
      if (item.isArchived) return false;

      // Module filter
      if (selectedModule === 'photos') {
        if (!item.attachments?.some((a) => a.type === 'image')) return false;
      } else if (selectedModule === 'documents') {
        if (!item.attachments?.some((a) => a.type === 'document' || a.type === 'pdf')) return false;
      } else if (selectedModule === 'voice') {
        if (!item.voiceNote) return false;
      } else if (selectedModule !== 'all' && item.moduleId !== selectedModule) {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && item.categoryId !== selectedCategory) {
        return false;
      }

      // Priority filter
      if (selectedPriority !== 'all' && item.priority !== selectedPriority) {
        return false;
      }

      // Status filter
      if (selectedStatus !== 'all' && item.status !== selectedStatus) {
        return false;
      }

      // Date filter
      if (dateFilter === 'today' && item.date !== today) return false;
      if (dateFilter === 'yesterday') {
        const yDate = new Date();
        yDate.setDate(yDate.getDate() - 1);
        const yStr = yDate.toISOString().split('T')[0];
        if (item.date !== yStr) return false;
      }
      if (dateFilter === 'week') {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        if (item.date < weekAgo.toISOString().split('T')[0]) return false;
      }
      if (dateFilter === 'month') {
        const monthAgo = new Date();
        monthAgo.setDate(monthAgo.getDate() - 30);
        if (item.date < monthAgo.toISOString().split('T')[0]) return false;
      }
      if (dateFilter === 'custom') {
        if (startDate && item.date < startDate) return false;
        if (endDate && item.date > endDate) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = item.title.toLowerCase().includes(q);
        const matchesDesc = (item.description || '').toLowerCase().includes(q);
        const matchesPerson = (item.vendorOrPerson || item.person || '').toLowerCase().includes(q);
        const matchesRef = (item.referenceNumber || item.fileNumber || item.billNumber || '').toLowerCase().includes(q);
        const matchesCat = (item.categoryName || '').toLowerCase().includes(q);
        const matchesTag = (item.tags || []).some((t) => t.toLowerCase().includes(q));

        if (!matchesTitle && !matchesDesc && !matchesPerson && !matchesRef && !matchesCat && !matchesTag) {
          return false;
        }
      }

      return true;
    });
  }, [entries, selectedModule, selectedCategory, selectedPriority, selectedStatus, dateFilter, startDate, endDate, searchQuery]);

  const handleDuplicate = (e: React.MouseEvent, entry: UniversalEntry) => {
    e.stopPropagation();
    const duplicated: UniversalEntry = {
      ...entry,
      id: `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      title: `${entry.title} (Copy)`,
      date: today,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveEntry(duplicated);
    reload();
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm('Delete this record?')) {
      deleteEntry(id);
      reload();
    }
  };

  const handleExportExcel = () => {
    exportEntriesToExcel(filteredEntries, `Daily_Life_Entries_${selectedModule}`);
  };

  const handleExportCSV = () => {
    exportEntriesToCSV(filteredEntries, `Daily_Life_Entries_${selectedModule}`);
  };

  const MODULE_TABS = [
    { id: 'all', label: 'All' },
    { id: 'office', label: 'Office' },
    { id: 'union', label: 'Union' },
    { id: 'personal', label: 'Personal' },
    { id: 'home', label: 'Home' },
    { id: 'expense', label: 'Expenses' },
    { id: 'credit', label: 'Credits' },
    { id: 'bills', label: 'Bills' },
    { id: 'tasks', label: 'Tasks' },
    { id: 'notes', label: 'Notes' },
    { id: 'events', label: 'Events' },
    { id: 'photos', label: 'Photos' },
    { id: 'documents', label: 'Documents' },
    { id: 'voice', label: 'Voice' },
  ];

  return (
    <div id="entries_view_container" className="space-y-4 pb-24 max-w-6xl mx-auto px-4 sm:px-6 pt-4">
      {/* Top Controls: Search bar & Filter Trigger */}
      <div className="flex items-center space-x-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search entries, persons, tags, ref nos..."
            className="w-full pl-9.5 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
          />
        </div>

        <button
          type="button"
          id="toggle_filters_btn"
          onClick={() => setShowFilters(!showFilters)}
          className={`p-2.5 rounded-full border text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
            showFilters || selectedCategory !== 'all' || selectedPriority !== 'all' || dateFilter !== 'all'
              ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-800 text-blue-600 dark:text-blue-400'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>

        <button
          type="button"
          id="export_excel_btn"
          onClick={handleExportExcel}
          title="Export Filtered Records to Excel (.xlsx)"
          className="p-2.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4" />
        </button>
      </div>

      {/* Module Horizontal Scroll Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs scrollbar-none">
        {MODULE_TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            id={`filter_tab_${tab.id}`}
            onClick={() => setSelectedModule(tab.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedModule === tab.id
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Expandable Advanced Filter Panel */}
      {showFilters && (
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3.5 shadow-xs animate-in fade-in duration-150">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-slate-200">
            <span className="uppercase tracking-wider text-slate-400">Filter Criteria</span>
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('all');
                setSelectedPriority('all');
                setSelectedStatus('all');
                setDateFilter('all');
                setStartDate('');
                setEndDate('');
              }}
              className="text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              Reset Filters
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-[11px] text-slate-500 font-semibold mb-1 block">Date Range</label>
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="all">All Dates</option>
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="week">Past 7 Days</option>
                <option value="month">Past 30 Days</option>
                <option value="custom">Custom Date Range</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold mb-1 block">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="all">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.moduleId})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold mb-1 block">Priority</label>
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="all">All Priorities</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-semibold mb-1 block">Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="paid">Paid</option>
              </select>
            </div>
          </div>

          {dateFilter === 'custom' && (
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-[11px] text-slate-500 font-semibold mb-1 block">From Date</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 font-semibold mb-1 block">To Date</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Entries List Header */}
      <div className="flex items-center justify-between px-1">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          Showing {filteredEntries.length} {filteredEntries.length === 1 ? 'Record' : 'Records'}
        </span>

        <button
          type="button"
          onClick={() => onOpenAddModal(selectedModule !== 'all' ? (selectedModule as ModuleId) : undefined)}
          className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New {selectedModule !== 'all' ? selectedModule : 'Entry'}</span>
        </button>
      </div>

      {/* Entries Cards */}
      {filteredEntries.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-2 shadow-xs">
          <Layers className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            No entries found
          </p>
          <p className="text-xs text-slate-400">
            Try adjusting your filters or click New Entry to add a record.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEntries.map((entry) => (
            <div
              key={entry.id}
              onClick={() => onSelectEntry(entry)}
              className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700/80 shadow-xs hover:shadow-sm transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between">
                <div className="space-y-1.5 flex-1 pr-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-900/40">
                      {entry.moduleId}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {entry.title}
                    </h3>
                  </div>

                  {entry.description && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                      {entry.description}
                    </p>
                  )}

                  {/* Metadata Chips */}
                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 pt-1">
                    <span className="flex items-center gap-1 text-slate-500 dark:text-slate-400">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {entry.date} {entry.time}
                    </span>

                    {entry.categoryName && (
                      <span className="font-medium text-slate-600 dark:text-slate-400">
                        • {entry.categoryName} {entry.subcategory ? `> ${entry.subcategory}` : ''}
                      </span>
                    )}

                    {(entry.vendorOrPerson || entry.person) && (
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        • {entry.vendorOrPerson || entry.person}
                      </span>
                    )}

                    {entry.attachments && entry.attachments.length > 0 && (
                      <span className="flex items-center gap-0.5 text-blue-600 dark:text-blue-400 font-bold">
                        <Paperclip className="w-3 h-3" /> {entry.attachments.length}
                      </span>
                    )}

                    {entry.voiceNote && (
                      <span className="flex items-center gap-0.5 text-rose-500 font-bold">
                        <Volume2 className="w-3 h-3" /> Audio
                      </span>
                    )}
                  </div>
                </div>

                {/* Right Side: Amount, Priority, Quick Action Icons */}
                <div className="flex flex-col items-end justify-between space-y-2">
                  {entry.amount !== undefined && (
                    <span className={`text-sm font-bold whitespace-nowrap ${entry.moduleId === 'credit' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                      {entry.moduleId === 'credit' ? '+' : '-'}{settings.currencySymbol}{entry.amount.toLocaleString()}
                    </span>
                  )}

                  <div className="flex items-center space-x-1 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={(e) => handleDuplicate(e, entry)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="Duplicate record"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleDelete(e, entry.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
