import React, { useState } from 'react';
import { Calendar as CalendarIcon, Plus, MapPin, Clock, Users, Building } from 'lucide-react';
import { UniversalEntry } from '../../types';
import { getEntries } from '../../services/storage';

interface EventsViewProps {
  onOpenAddEvent: () => void;
  onSelectEvent: (event: UniversalEntry) => void;
}

export const EventsView: React.FC<EventsViewProps> = ({
  onOpenAddEvent,
  onSelectEvent,
}) => {
  const [entries] = useState<UniversalEntry[]>(getEntries());

  const events = entries.filter((e) => (e.moduleId === 'events' || e.type === 'Event' || e.location) && !e.isArchived);

  return (
    <div id="events_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <CalendarIcon className="w-5 h-5 text-indigo-600" />
            <span>Events, Meetings & Programs</span>
          </h2>
          <p className="text-xs text-slate-500">{events.length} scheduled events</p>
        </div>

        <button
          type="button"
          onClick={onOpenAddEvent}
          className="px-3.5 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-indigo-700 active:scale-95 flex items-center gap-1"
        >
          <Plus className="w-4 h-4" />
          <span>New Event</span>
        </button>
      </div>

      {events.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-slate-400 text-xs">
          No events scheduled. Tap 'New Event' to add a meeting, hearing, or family program.
        </div>
      ) : (
        <div className="space-y-2.5">
          {events.map((event) => (
            <div
              key={event.id}
              onClick={() => onSelectEvent(event)}
              className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 shadow-xs cursor-pointer flex items-start justify-between group"
            >
              <div className="space-y-1.5 flex-1 pr-3">
                <div className="flex items-center space-x-2">
                  <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300">
                    {event.categoryName || 'Event'}
                  </span>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 transition-colors">
                    {event.title}
                  </h3>
                </div>

                {event.description && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                    {event.description}
                  </p>
                )}

                <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-1">
                  <span className="flex items-center gap-1 font-semibold text-slate-700 dark:text-slate-300">
                    <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                    {event.date} at {event.time}
                  </span>

                  {event.location && (
                    <span className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                      <MapPin className="w-3.5 h-3.5 text-rose-500" />
                      {event.location}
                    </span>
                  )}

                  {event.organization && (
                    <span className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                      <Building className="w-3.5 h-3.5 text-indigo-500" />
                      {event.organization}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
