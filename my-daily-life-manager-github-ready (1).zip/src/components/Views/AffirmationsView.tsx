import React, { useState } from 'react';
import { Smile, Plus, Trash2, Heart, CheckCircle2, Globe } from 'lucide-react';
import { AffirmationItem } from '../../types';
import { getAffirmations, saveAffirmation, deleteAffirmation, getSettings, updateSettings } from '../../services/storage';

export const AffirmationsView: React.FC = () => {
  const [settings, setSettings] = useState(getSettings());
  const [affirmations, setAffirmations] = useState<AffirmationItem[]>(getAffirmations(settings.language));
  const [newText, setNewText] = useState('');
  const [newCategory, setNewCategory] = useState('mindset');

  const reload = (lang = settings.language) => {
    setAffirmations(getAffirmations(lang));
  };

  const handleLanguageSwitch = (lang: 'en' | 'hi' | 'gu') => {
    const updated = updateSettings({ language: lang });
    setSettings(updated);
    reload(lang);
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    saveAffirmation({
      id: `aff-${Date.now()}`,
      text: newText.trim(),
      language: settings.language,
      category: newCategory,
      isCustom: true,
      createdAt: new Date().toISOString(),
    });

    setNewText('');
    reload();
  };

  const handleDelete = (id: string) => {
    deleteAffirmation(id);
    reload();
  };

  return (
    <div id="affirmations_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <Smile className="w-5 h-5 text-amber-500" />
            <span>Daily Affirmations & Motivation</span>
          </h2>
          <p className="text-xs text-slate-500">
            Positive thoughts and mental clarity reminders
          </p>
        </div>

        {/* Language Switcher */}
        <div className="flex items-center space-x-1.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
          <Globe className="w-3.5 h-3.5 text-slate-400 ml-1" />
          {[
            { id: 'en', label: 'English' },
            { id: 'hi', label: 'हिंदी (Hindi)' },
            { id: 'gu', label: 'ગુજરાતી (Gujarati)' },
          ].map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => handleLanguageSwitch(l.id as any)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                settings.language === l.id
                  ? 'bg-amber-500 text-white font-bold shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>

      {/* Add Custom Affirmation Form */}
      <form onSubmit={handleAdd} className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2.5">
        <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
          + Add Your Personal Mantra or Affirmation
        </label>
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder="e.g. 'I am focused, resilient and organized today.'"
            className="flex-1 px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-amber-500"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-amber-500 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-amber-600 active:scale-95 transition-all"
          >
            Add
          </button>
        </div>
      </form>

      {/* Affirmations List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {affirmations.map((aff) => (
          <div
            key={aff.id}
            className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-amber-200/60 dark:border-amber-900/40 shadow-xs flex items-start justify-between space-x-3"
          >
            <div className="space-y-1 flex-1">
              <span className="text-[10px] uppercase font-bold tracking-wider text-amber-600 dark:text-amber-400">
                {aff.category || 'Mindset'}
              </span>
              <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200 leading-relaxed italic">
                "{aff.text}"
              </p>
            </div>

            {aff.isCustom && (
              <button
                type="button"
                onClick={() => handleDelete(aff.id)}
                className="text-slate-400 hover:text-rose-500 p-1"
                title="Delete custom affirmation"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
