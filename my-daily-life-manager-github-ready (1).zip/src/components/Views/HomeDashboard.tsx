import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Briefcase,
  Users,
  User,
  Home as HomeIcon,
  TrendingDown,
  TrendingUp,
  Receipt,
  CheckSquare,
  Sparkles,
  Smile,
  ChevronRight,
  Volume2,
  Paperclip,
  CheckCircle2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  UniversalEntry,
  ModuleId,
  AffirmationItem,
} from '../../types';
import {
  getEntries,
  getAffirmations,
  getSettings,
  saveEntry,
} from '../../services/storage';

interface HomeDashboardProps {
  onOpenQuickAdd: () => void;
  onOpenModuleForm: (moduleId: ModuleId, initialData?: Partial<UniversalEntry>) => void;
  onNavigateTab: (tab: any) => void;
  onSelectEntry: (entry: UniversalEntry) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onOpenQuickAdd,
  onOpenModuleForm,
  onNavigateTab,
  onSelectEntry,
}) => {
  const [entries, setEntries] = useState<UniversalEntry[]>([]);
  const [affirmations, setAffirmations] = useState<AffirmationItem[]>([]);
  const [activeAffirmationIndex, setActiveAffirmationIndex] = useState(0);
  const settings = getSettings();

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    setEntries(getEntries());
    setAffirmations(getAffirmations(settings.language));
  }, [settings.language]);

  // Today's records
  const todayEntries = entries.filter((e) => e.date === todayStr && !e.isArchived);
  
  // Financial totals today
  const todayExpenses = todayEntries
    .filter((e) => e.moduleId === 'expense' || e.type === 'Expense')
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const todayCredits = todayEntries
    .filter((e) => e.moduleId === 'credit' || e.type === 'Credit / Income')
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const netToday = todayCredits - todayExpenses;

  // Pending & Priority Tasks
  const pendingTasks = entries.filter(
    (e) => (e.moduleId === 'tasks' || e.type === 'Task' || e.subtasks?.length) && e.status !== 'completed' && !e.isArchived
  );

  // Upcoming Bills (within next 7 days or overdue)
  const upcomingBills = entries.filter(
    (e) => (e.moduleId === 'bills' || e.type === 'Bill') && e.status !== 'paid' && !e.isArchived
  );

  // Current Affirmation
  const currentAffirmation = affirmations.length > 0 ? affirmations[activeAffirmationIndex % affirmations.length] : null;

  const handleToggleTaskStatus = (task: UniversalEntry) => {
    const isCompleted = task.status === 'completed';
    saveEntry({
      ...task,
      status: isCompleted ? 'pending' : 'completed',
    });
    setEntries(getEntries());

    if (!isCompleted) {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 },
      });
    }
  };

  const QUICK_ADD_BUTTONS = [
    { id: 'office', label: 'Office', icon: Briefcase, color: 'text-blue-600 dark:text-blue-400', hoverBg: 'hover:bg-blue-50 dark:hover:bg-blue-950/40' },
    { id: 'union', label: 'Union', icon: Users, color: 'text-indigo-600 dark:text-indigo-400', hoverBg: 'hover:bg-indigo-50 dark:hover:bg-indigo-950/40' },
    { id: 'home', label: 'Home', icon: HomeIcon, color: 'text-rose-600 dark:text-rose-400', hoverBg: 'hover:bg-rose-50 dark:hover:bg-rose-950/40' },
    { id: 'expense', label: 'Expense', icon: TrendingDown, color: 'text-emerald-600 dark:text-emerald-400', hoverBg: 'hover:bg-emerald-50 dark:hover:bg-emerald-950/40' },
    { id: 'tasks', label: 'Task', icon: CheckSquare, color: 'text-amber-600 dark:text-amber-400', hoverBg: 'hover:bg-amber-50 dark:hover:bg-amber-950/40' },
    { id: 'credit', label: 'Credit', icon: TrendingUp, color: 'text-green-600 dark:text-green-400', hoverBg: 'hover:bg-green-50 dark:hover:bg-green-950/40' },
    { id: 'bills', label: 'Bill', icon: Receipt, color: 'text-orange-600 dark:text-orange-400', hoverBg: 'hover:bg-orange-50 dark:hover:bg-orange-950/40' },
    { id: 'personal', label: 'Personal', icon: User, color: 'text-purple-600 dark:text-purple-400', hoverBg: 'hover:bg-purple-50 dark:hover:bg-purple-950/40' },
  ];

  const getModuleIndicatorColor = (moduleId: string) => {
    switch (moduleId) {
      case 'office':
        return 'bg-blue-500';
      case 'union':
        return 'bg-indigo-500';
      case 'expense':
        return 'bg-rose-500';
      case 'credit':
        return 'bg-emerald-500';
      case 'bills':
        return 'bg-amber-500';
      case 'tasks':
        return 'bg-sky-500';
      case 'home':
        return 'bg-purple-500';
      default:
        return 'bg-slate-400';
    }
  };

  return (
    <div id="home_dashboard_view" className="space-y-5 pb-24 max-w-6xl mx-auto px-4 sm:px-6 pt-4">
      {/* 1. Quick Add Entry Section */}
      <section id="widget_quick_actions" className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Quick Add Entry
          </h2>
          <button
            type="button"
            onClick={onOpenQuickAdd}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <span>Smart Assistant</span>
            <Sparkles className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
          {QUICK_ADD_BUTTONS.map((item) => {
            const IconComp = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                id={`dash_btn_${item.id}`}
                onClick={() => onOpenModuleForm(item.id as ModuleId)}
                className={`flex flex-col items-center justify-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 transition-all text-center group cursor-pointer hover:border-slate-200 dark:hover:border-slate-700 ${item.hoverBg}`}
              >
                <div className={`p-1.5 rounded-lg mb-1 ${item.color} group-hover:scale-110 transition-transform`}>
                  <IconComp className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-200">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 2. Top Metric Columns: Financial Overview & Daily Affirmation */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        {/* Financial Overview Card */}
        <section id="widget_financial_snapshot" className="md:col-span-6 bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                Financial Overview
              </h2>
              <button
                type="button"
                onClick={() => onNavigateTab('finance')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                View Details →
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-emerald-50 dark:bg-emerald-950/40 p-3.5 rounded-xl border border-emerald-100/80 dark:border-emerald-900/40">
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wider">
                  Today's Income
                </p>
                <p className="text-xl font-bold text-emerald-700 dark:text-emerald-300 mt-1">
                  {settings.currencySymbol}{todayCredits.toLocaleString()}
                </p>
              </div>
              <div className="bg-rose-50 dark:bg-rose-950/40 p-3.5 rounded-xl border border-rose-100/80 dark:border-rose-900/40">
                <p className="text-[10px] text-rose-600 dark:text-rose-400 font-bold uppercase tracking-wider">
                  Today's Expense
                </p>
                <p className="text-xl font-bold text-rose-700 dark:text-rose-300 mt-1">
                  {settings.currencySymbol}{todayExpenses.toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-3 flex justify-between items-center">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Net Difference</span>
            <span className={`text-sm font-bold ${netToday >= 0 ? 'text-slate-900 dark:text-slate-100' : 'text-rose-600 dark:text-rose-400'}`}>
              {netToday >= 0 ? '+ ' : '- '}{settings.currencySymbol}{Math.abs(netToday).toLocaleString()}
            </span>
          </div>
        </section>

        {/* Daily Affirmation Card */}
        <section id="widget_daily_affirmation" className="md:col-span-6 bg-indigo-600 dark:bg-indigo-700 rounded-2xl p-5 shadow-sm text-white relative overflow-hidden flex flex-col justify-between">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xs font-bold text-indigo-200 uppercase tracking-wider">
                Daily Affirmation
              </h2>
              {affirmations.length > 1 && (
                <button
                  type="button"
                  onClick={() => setActiveAffirmationIndex((prev) => prev + 1)}
                  className="text-[10px] font-bold px-2 py-0.5 bg-white/20 hover:bg-white/30 rounded-full text-white transition-colors"
                >
                  Next ↻
                </button>
              )}
            </div>
            <p className="text-sm sm:text-base font-serif italic leading-relaxed mt-2 text-indigo-50">
              "{currentAffirmation ? currentAffirmation.text : 'I am focused, organized, and I complete today\'s important work with ease.'}"
            </p>
          </div>
          <div className="relative z-10 flex items-center gap-2 mt-4 text-xs text-indigo-200">
            <Smile className="w-4 h-4" />
            <span>Stay positive and productive</span>
          </div>
          {/* Subtle Glow Backdrop */}
          <div className="absolute -top-6 -right-6 w-28 h-28 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
        </section>
      </div>

      {/* 3. Middle Section: Recent Entries & Priority Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Recent Entries */}
        <section id="widget_recent_entries" className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
              Recent Entries ({todayEntries.length})
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab('entries')}
              className="text-blue-600 dark:text-blue-400 text-xs font-bold hover:underline"
            >
              View All Entries
            </button>
          </div>

          {todayEntries.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              No entries logged yet for today. Tap any shortcut above to record an activity.
            </div>
          ) : (
            <div className="space-y-3">
              {todayEntries.slice(0, 5).map((entry) => (
                <div
                  key={entry.id}
                  onClick={() => onSelectEntry(entry)}
                  className="flex gap-3.5 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 border border-transparent hover:border-slate-100 dark:hover:border-slate-800 cursor-pointer transition-all"
                >
                  <div className={`w-1 ${getModuleIndicatorColor(entry.moduleId)} rounded-full shrink-0`}></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start gap-2">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                        {entry.title}
                      </h3>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded shrink-0">
                        {entry.moduleId}
                      </span>
                    </div>

                    {entry.description && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-1">
                        {entry.description}
                      </p>
                    )}

                    <div className="flex justify-between items-center mt-2 text-[10px] text-slate-400">
                      <div className="flex items-center gap-3">
                        <span>{entry.time}</span>
                        {entry.categoryName && <span className="font-medium text-slate-500 dark:text-slate-400">🏷️ {entry.categoryName}</span>}
                        {entry.attachments?.length > 0 && (
                          <span className="flex items-center gap-0.5 text-blue-600 dark:text-blue-400 font-bold">
                            <Paperclip className="w-3 h-3" /> {entry.attachments.length}
                          </span>
                        )}
                        {entry.voiceNote && (
                          <span className="flex items-center gap-0.5 text-rose-500 font-bold">
                            <Volume2 className="w-3 h-3" /> Audio
                          </span>
                        )}
                      </div>

                      {entry.amount !== undefined && (
                        <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                          {settings.currencySymbol}{entry.amount.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Priority Tasks & Upcoming Bills */}
        <div className="lg:col-span-5 space-y-5">
          {/* Priority Tasks */}
          <section id="widget_priority_tasks" className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                Priority Tasks ({pendingTasks.length})
              </h2>
              <button
                type="button"
                onClick={() => onNavigateTab('tasks')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                View All →
              </button>
            </div>

            {pendingTasks.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">🎉 No pending tasks! All caught up.</p>
            ) : (
              <div className="space-y-2">
                {pendingTasks.slice(0, 4).map((task) => {
                  const isCritical = task.priority === 'critical';
                  const isHigh = task.priority === 'high';
                  return (
                    <div
                      key={task.id}
                      className={`flex items-center gap-3 p-2.5 rounded-xl border transition-colors ${
                        isCritical
                          ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-100 dark:border-rose-900/50'
                          : isHigh
                          ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-100 dark:border-amber-900/50'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-100 dark:border-slate-800'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => handleToggleTaskStatus(task)}
                        className={`w-4 h-4 border-2 rounded cursor-pointer flex items-center justify-center ${
                          isCritical ? 'border-rose-400' : isHigh ? 'border-amber-400' : 'border-slate-400'
                        }`}
                      >
                        {task.status === 'completed' && <div className="w-2 h-2 bg-blue-600 rounded-xs" />}
                      </button>
                      <div
                        onClick={() => onSelectEntry(task)}
                        className="flex-1 min-w-0 cursor-pointer"
                      >
                        <p className={`text-xs font-bold truncate ${isCritical ? 'text-rose-950 dark:text-rose-200' : isHigh ? 'text-amber-950 dark:text-amber-200' : 'text-slate-800 dark:text-slate-200'}`}>
                          {task.title}
                        </p>
                        <p className={`text-[9px] uppercase font-bold mt-0.5 ${isCritical ? 'text-rose-700 dark:text-rose-400' : isHigh ? 'text-amber-700 dark:text-amber-400' : 'text-slate-400'}`}>
                          {task.priority || 'Normal'} • {task.dueDate || 'Today'}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Upcoming Bills */}
          <section id="widget_upcoming_bills" className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                Upcoming Bills ({upcomingBills.length})
              </h2>
              <button
                type="button"
                onClick={() => onNavigateTab('finance')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                Manage Bills →
              </button>
            </div>

            {upcomingBills.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">All bills are settled! 👍</p>
            ) : (
              <div className="space-y-2.5">
                {upcomingBills.slice(0, 3).map((bill) => (
                  <div
                    key={bill.id}
                    onClick={() => onSelectEntry(bill)}
                    className="flex items-center gap-3 p-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer border border-transparent hover:border-slate-100 dark:hover:border-slate-800 transition-colors"
                  >
                    <div className="w-8 h-8 bg-amber-100 dark:bg-amber-950/60 rounded-lg flex items-center justify-center text-amber-600 dark:text-amber-400 font-bold text-sm">
                      ⚡
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                        {bill.title}
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        {bill.dueDate ? `Due: ${bill.dueDate}` : 'Due soon'}
                      </p>
                    </div>
                    <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                      {settings.currencySymbol}{bill.amount?.toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
