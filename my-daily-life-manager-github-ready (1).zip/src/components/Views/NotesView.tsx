import React, { useState } from 'react';
import { FileText, Plus, Pin, Calendar, Tag, Paperclip, Volume2 } from 'lucide-react';
import { UniversalEntry } from '../../types';
import { getEntries, saveEntry } from '../../services/storage';

interface NotesViewProps {
  onOpenAddNote: () => void;
  onSelectNote: (note: UniversalEntry) => void;
}

export const NotesView: React.FC<NotesViewProps> = ({
  onOpenAddNote,
  onSelectNote,
}) => {
  const [entries, setEntries] = useState<UniversalEntry[]>(getEntries());

  const reload = () => setEntries(getEntries());

  const notes = entries.filter((e) => (e.moduleId === 'notes' || e.type === 'Note') && !e.isArchived);

  return (
    <div id="notes_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <FileText className="w-5 h-5 text-indigo-600" />
            <span>Notes, Memos & Ideas</span>
          </h2>
          <p className="text-xs text-slate-500">{notes.length} saved notes</p>
        </div>

        <button
          type="button"
          onClick={onOpenAddNote}
          className="px-3.5 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-indigo-700 active:scale-95 flex items-center gap-1"
        >
          <Plus className="w-4 h-4" />
          <span>New Note</span>
        </button>
      </div>

      {notes.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-slate-400 text-xs">
          No notes yet. Tap 'New Note' to jot down your thoughts, ideas, or meeting memos.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {notes.map((note) => (
            <div
              key={note.id}
              onClick={() => onSelectNote(note)}
              className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 shadow-xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between space-y-3"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100">
                    {note.title}
                  </h3>
                  {note.categoryName && (
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      {note.categoryName}
                    </span>
                  )}
                </div>

                {note.description && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed whitespace-pre-wrap">
                    {note.description}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400">
                <span>{note.date}</span>
                <div className="flex items-center gap-2">
                  {note.attachments && note.attachments.length > 0 && (
                    <span className="flex items-center gap-0.5 text-indigo-500 font-medium">
                      <Paperclip className="w-3 h-3" /> {note.attachments.length}
                    </span>
                  )}
                  {note.voiceNote && (
                    <span className="flex items-center gap-0.5 text-rose-500 font-medium">
                      <Volume2 className="w-3 h-3" /> Audio
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
