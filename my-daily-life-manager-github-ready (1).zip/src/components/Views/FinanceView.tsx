import React, { useState, useMemo } from 'react';
import {
  TrendingDown,
  TrendingUp,
  Receipt,
  Plus,
  Calendar,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Layers,
  PieChart as PieIcon,
  CreditCard,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UniversalEntry, ModuleId } from '../../types';
import { getEntries, saveEntry, getSettings, exportEntriesToExcel } from '../../services/storage';

interface FinanceViewProps {
  onOpenAddFinance: (moduleId: 'expense' | 'credit' | 'bills') => void;
  onSelectEntry: (entry: UniversalEntry) => void;
}

export const FinanceView: React.FC<FinanceViewProps> = ({
  onOpenAddFinance,
  onSelectEntry,
}) => {
  const settings = getSettings();
  const [entries, setEntries] = useState<UniversalEntry[]>(getEntries());
  const [subTab, setSubTab] = useState<'all' | 'expense' | 'credit' | 'bills'>('all');
  const [timeRange, setTimeRange] = useState<'month' | 'today' | 'year' | 'all'>('month');

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthPrefix = todayStr.slice(0, 7); // 'YYYY-MM'
  const currentYearPrefix = todayStr.slice(0, 4);

  const reload = () => setEntries(getEntries());

  // Filter financial entries by time range
  const financeEntries = useMemo(() => {
    return entries.filter((e) => {
      if (e.isArchived) return false;
      const isFin = e.moduleId === 'expense' || e.moduleId === 'credit' || e.moduleId === 'bills' || e.amount !== undefined;
      if (!isFin) return false;

      if (timeRange === 'today' && e.date !== todayStr) return false;
      if (timeRange === 'month' && !e.date.startsWith(currentMonthPrefix)) return false;
      if (timeRange === 'year' && !e.date.startsWith(currentYearPrefix)) return false;

      return true;
    });
  }, [entries, timeRange, todayStr, currentMonthPrefix, currentYearPrefix]);

  // Totals
  const totalExpenses = useMemo(() => {
    return financeEntries
      .filter((e) => e.moduleId === 'expense' || e.type === 'Expense')
      .reduce((sum, e) => sum + (e.amount || 0), 0);
  }, [financeEntries]);

  const totalCredits = useMemo(() => {
    return financeEntries
      .filter((e) => e.moduleId === 'credit' || e.type === 'Credit / Income')
      .reduce((sum, e) => sum + (e.amount || 0), 0);
  }, [financeEntries]);

  const netBalance = totalCredits - totalExpenses;

  // Unpaid bills count & total
  const unpaidBills = useMemo(() => {
    return entries.filter(
      (e) => (e.moduleId === 'bills' || e.type === 'Bill') && e.status !== 'paid' && !e.isArchived
    );
  }, [entries]);

  const unpaidBillsTotal = unpaidBills.reduce((sum, b) => sum + (b.amount || 0), 0);

  // Category breakdown for expenses
  const categoryBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    financeEntries
      .filter((e) => e.moduleId === 'expense' || e.type === 'Expense')
      .forEach((e) => {
        const cat = e.categoryName || 'Other Expense';
        map[cat] = (map[cat] || 0) + (e.amount || 0);
      });

    return Object.entries(map).map(([name, total]) => ({
      name,
      total,
      percentage: totalExpenses > 0 ? Math.round((total / totalExpenses) * 100) : 0,
    })).sort((a, b) => b.total - a.total);
  }, [financeEntries, totalExpenses]);

  // Payment mode breakdown
  const paymentModeBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    financeEntries.forEach((e) => {
      const mode = e.paymentMode || 'Cash';
      map[mode] = (map[mode] || 0) + (e.amount || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [financeEntries]);

  // Filtered list by subTab
  const displayList = useMemo(() => {
    return financeEntries.filter((e) => {
      if (subTab === 'expense') return e.moduleId === 'expense' || e.type === 'Expense';
      if (subTab === 'credit') return e.moduleId === 'credit' || e.type === 'Credit / Income';
      if (subTab === 'bills') return e.moduleId === 'bills' || e.type === 'Bill';
      return true;
    });
  }, [financeEntries, subTab]);

  const handleMarkBillPaid = (e: React.MouseEvent, bill: UniversalEntry) => {
    e.stopPropagation();
    saveEntry({
      ...bill,
      status: 'paid',
      updatedAt: new Date().toISOString(),
    });
    reload();
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.8 },
    });
  };

  const handleExportFinance = () => {
    exportEntriesToExcel(financeEntries, `Finance_Report_${timeRange}`);
  };

  return (
    <div id="finance_view_container" className="space-y-5 pb-24 max-w-6xl mx-auto px-4 sm:px-6 pt-4">
      {/* Header & Quick Add Financial Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span>Finance, Expenses & Bills</span>
          </h2>
          <p className="text-xs text-slate-400 font-medium">
            Track daily cash flow, income sources and upcoming bill dues
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            id="add_expense_btn"
            onClick={() => onOpenAddFinance('expense')}
            className="px-3.5 py-1.5 bg-rose-600 text-white rounded-full text-xs font-bold shadow-xs hover:bg-rose-700 active:scale-95 flex items-center gap-1 cursor-pointer transition-all"
          >
            <TrendingDown className="w-3.5 h-3.5" />
            <span>+ Expense</span>
          </button>
          <button
            type="button"
            id="add_credit_btn"
            onClick={() => onOpenAddFinance('credit')}
            className="px-3.5 py-1.5 bg-emerald-600 text-white rounded-full text-xs font-bold shadow-xs hover:bg-emerald-700 active:scale-95 flex items-center gap-1 cursor-pointer transition-all"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+ Credit</span>
          </button>
          <button
            type="button"
            id="add_bill_btn"
            onClick={() => onOpenAddFinance('bills')}
            className="px-3.5 py-1.5 bg-amber-600 text-white rounded-full text-xs font-bold shadow-xs hover:bg-amber-700 active:scale-95 flex items-center gap-1 cursor-pointer transition-all"
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>+ Bill</span>
          </button>
        </div>
      </div>

      {/* Time Range Selector & Excel Export */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-1 bg-slate-200/60 dark:bg-slate-800 p-1 rounded-full text-xs">
          {[
            { id: 'today', label: 'Today' },
            { id: 'month', label: 'This Month' },
            { id: 'year', label: 'This Year' },
            { id: 'all', label: 'All Time' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTimeRange(t.id as any)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                timeRange === t.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleExportFinance}
          className="p-2.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1 hover:bg-emerald-100 transition-colors cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span className="hidden sm:inline">Export Report</span>
        </button>
      </div>

      {/* Summary Scorecards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Total Expense */}
        <div className="bg-white dark:bg-slate-900 p-4.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">
              Total Expenses
            </span>
            <div className="p-1.5 bg-rose-50 dark:bg-rose-950/60 text-rose-600 rounded-lg">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            {settings.currencySymbol}{totalExpenses.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400">
            {timeRange === 'month' ? 'Current Month' : timeRange}
          </span>
        </div>

        {/* Total Credits */}
        <div className="bg-white dark:bg-slate-900 p-4.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
              Total Income / Credits
            </span>
            <div className="p-1.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            {settings.currencySymbol}{totalCredits.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400">
            {timeRange === 'month' ? 'Current Month' : timeRange}
          </span>
        </div>

        {/* Net Balance */}
        <div className="bg-white dark:bg-slate-900 p-4.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              Net Savings / Balance
            </span>
            <div className="p-1.5 bg-blue-50 dark:bg-blue-950/60 text-blue-600 rounded-lg">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <p className={`text-2xl font-bold ${netBalance >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
            {netBalance >= 0 ? '+' : ''}{settings.currencySymbol}{netBalance.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400">Credits minus expenses</span>
        </div>
      </div>

      {/* Unpaid Bills Alert Banner */}
      {unpaidBills.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 p-4 rounded-2xl flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-500 text-white rounded-xl">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-950 dark:text-amber-200">
                {unpaidBills.length} Unpaid Bills Due ({settings.currencySymbol}{unpaidBillsTotal.toLocaleString()})
              </h4>
              <p className="text-[11px] text-amber-800/80 dark:text-amber-300">
                Pay on time to avoid service disruption or late penalty charges.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSubTab('bills')}
            className="px-3.5 py-1.5 bg-amber-600 text-white text-xs font-bold rounded-full shadow-xs hover:bg-amber-700 cursor-pointer"
          >
            Review Bills
          </button>
        </div>
      )}

      {/* Expense Category Breakdown */}
      {categoryBreakdown.length > 0 && (
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3.5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-blue-500" />
              <span>Expense Breakdown by Category</span>
            </span>
          </div>

          <div className="space-y-3">
            {categoryBreakdown.slice(0, 5).map((cat) => (
              <div key={cat.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300">
                  <span>{cat.name}</span>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold">{settings.currencySymbol}{cat.total.toLocaleString()}</span>
                    <span className="text-[10px] text-slate-400 font-semibold">({cat.percentage}%)</span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${cat.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub Tabs: All, Expenses, Credits, Bills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs scrollbar-none pt-1">
        {[
          { id: 'all', label: 'All Transactions' },
          { id: 'expense', label: 'Expenses Only' },
          { id: 'credit', label: 'Credits / Income' },
          { id: 'bills', label: `Bills (${unpaidBills.length} unpaid)` },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setSubTab(tab.id as any)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              subTab === tab.id
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Transactions List */}
      <div className="space-y-3">
        {displayList.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-slate-400 text-xs shadow-xs">
            No financial transactions found for this period.
          </div>
        ) : (
          displayList.map((entry) => {
            const isCredit = entry.moduleId === 'credit' || entry.type === 'Credit / Income';
            const isBill = entry.moduleId === 'bills' || entry.type === 'Bill';
            const isPaid = entry.status === 'paid';

            return (
              <div
                key={entry.id}
                onClick={() => onSelectEntry(entry)}
                className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 shadow-xs cursor-pointer flex items-center justify-between transition-all"
              >
                <div className="space-y-1 flex-1 pr-3">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded ${
                        isCredit
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-900/40'
                          : isBill
                          ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-100 dark:border-amber-900/40'
                          : 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-900/40'
                      }`}
                    >
                      {entry.type || entry.moduleId}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {entry.title}
                    </h4>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                    <span>{entry.date}</span>
                    {entry.categoryName && <span>• {entry.categoryName}</span>}
                    {entry.paymentMode && <span>• {entry.paymentMode}</span>}
                    {entry.vendorOrPerson && <span>• {entry.vendorOrPerson}</span>}
                    {isBill && entry.dueDate && (
                      <span className="font-semibold text-amber-600 dark:text-amber-400">
                        Due: {entry.dueDate}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end space-y-1.5">
                  <span
                    className={`text-sm font-bold whitespace-nowrap ${
                      isCredit ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {isCredit ? '+' : '-'}{settings.currencySymbol}{entry.amount?.toLocaleString()}
                  </span>

                  {isBill && !isPaid && (
                    <button
                      type="button"
                      onClick={(e) => handleMarkBillPaid(e, entry)}
                      className="px-3 py-1 bg-emerald-600 text-white rounded-full text-[10px] font-bold shadow-xs hover:bg-emerald-700 active:scale-95 cursor-pointer"
                    >
                      Mark Paid
                    </button>
                  )}

                  {isBill && isPaid && (
                    <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-0.5">
                      <CheckCircle2 className="w-3 h-3" /> Paid
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
