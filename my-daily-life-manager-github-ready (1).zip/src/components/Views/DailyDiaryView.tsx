import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Calendar,
  Save,
  Smile,
  CheckCircle2,
  Sparkles,
  Heart,
  Target,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { DailyDiaryEntry } from '../../types';
import { getDiaryEntryByDate, saveDiaryEntry, getDiaryEntries } from '../../services/storage';

export const DailyDiaryView: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [diaryEntry, setDiaryEntry] = useState<DailyDiaryEntry | null>(null);
  
  // Diary fields
  const [mood, setMood] = useState<'happy' | 'neutral' | 'tired' | 'stressed' | 'excited'>('happy');
  const [content, setContent] = useState('');
  const [highlights, setHighlights] = useState('');
  const [challenges, setChallenges] = useState('');
  const [gratitude, setGratitude] = useState('');
  const [tomorrowFocus, setTomorrowFocus] = useState('');
  const [isSavedNotice, setIsSavedNotice] = useState(false);

  // Load diary on date change
  useEffect(() => {
    const entry = getDiaryEntryByDate(selectedDate);
    if (entry) {
      setDiaryEntry(entry);
      setMood(entry.mood || 'happy');
      setContent(entry.content || '');
      setHighlights(entry.highlights || '');
      setChallenges(entry.challenges || '');
      setGratitude(entry.gratitude || '');
      setTomorrowFocus(entry.tomorrowFocus || '');
    } else {
      setDiaryEntry(null);
      setMood('happy');
      setContent('');
      setHighlights('');
      setChallenges('');
      setGratitude('');
      setTomorrowFocus('');
    }
  }, [selectedDate]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const saved = saveDiaryEntry({
      id: diaryEntry?.id || `diary-${selectedDate}`,
      date: selectedDate,
      mood,
      content,
      highlights: highlights || undefined,
      challenges: challenges || undefined,
      gratitude: gratitude || undefined,
      tomorrowFocus: tomorrowFocus || undefined,
      createdAt: diaryEntry?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setDiaryEntry(saved);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2500);
  };

  const handleDateShift = (deltaDays: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + deltaDays);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const MOODS = [
    { id: 'happy', label: '😊 Great / Productive' },
    { id: 'excited', label: '🤩 Energized' },
    { id: 'neutral', label: '😐 Balanced / Normal' },
    { id: 'tired', label: '😴 Exhausted' },
    { id: 'stressed', label: '😟 Challenging' },
  ];

  return (
    <div id="daily_diary_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      {/* Header & Date Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            <span>Daily Personal Diary & Journal</span>
          </h2>
          <p className="text-xs text-slate-500">
            Reflect on thoughts, accomplishments, gratitude, and future plans
          </p>
        </div>

        {/* Date Shift Navigator */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => handleDateShift(-1)}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
            title="Previous Day"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
          />

          <button
            type="button"
            onClick={() => handleDateShift(1)}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
            title="Next Day"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {isSavedNotice && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold rounded-xl flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Diary entry saved successfully!</span>
        </div>
      )}

      {/* Diary Form */}
      <form onSubmit={handleSave} className="space-y-4">
        {/* Mood Tracker */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Smile className="w-4 h-4 text-amber-500" />
            <span>How was your day? (Mood)</span>
          </label>
          <div className="flex flex-wrap gap-2 pt-1">
            {MOODS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMood(m.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  mood === m.id
                    ? 'bg-indigo-600 text-white shadow-xs scale-102 font-bold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main Diary Story / Notes */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Daily Journal & Key Events
          </label>
          <textarea
            rows={5}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write freely about today's meetings, conversations, experiences, reflections..."
            className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed"
          />
        </div>

        {/* Structured Reflection Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {/* Highlights & Wins */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-500" />
              <span>Today's Highlights & Wins</span>
            </label>
            <textarea
              rows={2}
              value={highlights}
              onChange={(e) => setHighlights(e.target.value)}
              placeholder="What went well today?"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Challenges / Lessons */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-amber-500" />
              <span>Challenges & Lessons Learned</span>
            </label>
            <textarea
              rows={2}
              value={challenges}
              onChange={(e) => setChallenges(e.target.value)}
              placeholder="What challenged you and what did you learn?"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Gratitude */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-rose-500" />
              <span>Gratitude / Thankfulness</span>
            </label>
            <textarea
              rows={2}
              value={gratitude}
              onChange={(e) => setGratitude(e.target.value)}
              placeholder="3 things or people I am grateful for today..."
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Tomorrow's Top Focus */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-indigo-500" />
              <span>Tomorrow's Priority Focus</span>
            </label>
            <textarea
              rows={2}
              value={tomorrowFocus}
              onChange={(e) => setTomorrowFocus(e.target.value)}
              placeholder="What are the top 1-2 goals for tomorrow?"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            id="save_diary_btn"
            className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-indigo-700 active:scale-95 flex items-center gap-1.5 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Save Daily Diary</span>
          </button>
        </div>
      </form>
    </div>
  );
};
