import React, { useState, useMemo } from 'react';
import {
  CheckSquare,
  CheckCircle2,
  Circle,
  Clock,
  Calendar,
  AlertTriangle,
  Plus,
  Filter,
  Tag,
  Flame,
  Check,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UniversalEntry, PriorityLevel, EntryStatus } from '../../types';
import { getEntries, saveEntry } from '../../services/storage';

interface TasksViewProps {
  onOpenAddTask: () => void;
  onSelectTask: (task: UniversalEntry) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({
  onOpenAddTask,
  onSelectTask,
}) => {
  const [entries, setEntries] = useState<UniversalEntry[]>(getEntries());
  const [statusFilter, setStatusFilter] = useState<'pending' | 'all' | 'in_progress' | 'completed'>('pending');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [moduleFilter, setModuleFilter] = useState<string>('all');

  const todayStr = new Date().toISOString().split('T')[0];

  const reload = () => setEntries(getEntries());

  // All task-like entries
  const tasks = useMemo(() => {
    return entries.filter(
      (e) => (e.moduleId === 'tasks' || e.type === 'Task' || e.subtasks?.length) && !e.isArchived
    );
  }, [entries]);

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (statusFilter === 'pending' && t.status === 'completed') return false;
      if (statusFilter === 'in_progress' && t.status !== 'in_progress') return false;
      if (statusFilter === 'completed' && t.status !== 'completed') return false;

      if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
      if (moduleFilter !== 'all' && t.moduleId !== moduleFilter) return false;

      return true;
    });
  }, [tasks, statusFilter, priorityFilter, moduleFilter]);

  // Group by timeline / due date
  const groupedTasks = useMemo(() => {
    const overdue: UniversalEntry[] = [];
    const today: UniversalEntry[] = [];
    const tomorrow: UniversalEntry[] = [];
    const upcoming: UniversalEntry[] = [];
    const noDate: UniversalEntry[] = [];

    const tomorrowDate = new Date();
    tomorrowDate.setDate(tomorrowDate.getDate() + 1);
    const tomorrowStr = tomorrowDate.toISOString().split('T')[0];

    filteredTasks.forEach((t) => {
      const d = t.dueDate || t.date;
      if (!d) {
        noDate.push(t);
      } else if (d < todayStr && t.status !== 'completed') {
        overdue.push(t);
      } else if (d === todayStr) {
        today.push(t);
      } else if (d === tomorrowStr) {
        tomorrow.push(t);
      } else {
        upcoming.push(t);
      }
    });

    return { overdue, today, tomorrow, upcoming, noDate };
  }, [filteredTasks, todayStr]);

  const handleToggleTask = (e: React.MouseEvent, task: UniversalEntry) => {
    e.stopPropagation();
    const isCompleted = task.status === 'completed';
    const updated = saveEntry({
      ...task,
      status: isCompleted ? 'pending' : 'completed',
    });
    reload();

    if (!isCompleted) {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.8 },
      });
    }
  };

  const handleToggleSubtask = (e: React.MouseEvent, task: UniversalEntry, subtaskId: string) => {
    e.stopPropagation();
    const updatedSubtasks = (task.subtasks || []).map((s) =>
      s.id === subtaskId ? { ...s, isCompleted: !s.isCompleted } : s
    );
    const allDone = updatedSubtasks.length > 0 && updatedSubtasks.every((s) => s.isCompleted);
    saveEntry({
      ...task,
      subtasks: updatedSubtasks,
      status: allDone ? 'completed' : task.status,
    });
    reload();
  };

  const renderTaskList = (list: UniversalEntry[], title: string, badgeColor: string) => {
    if (list.length === 0) return null;

    return (
      <div className="space-y-2.5">
        <div className="flex items-center space-x-2 px-1">
          <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${badgeColor}`}>
            {title} ({list.length})
          </span>
        </div>

        <div className="space-y-2.5">
          {list.map((task) => {
            const isDone = task.status === 'completed';
            const totalSubtasks = task.subtasks?.length || 0;
            const doneSubtasks = task.subtasks?.filter((s) => s.isCompleted).length || 0;
            const subtaskPercent = totalSubtasks > 0 ? Math.round((doneSubtasks / totalSubtasks) * 100) : 0;

            return (
              <div
                key={task.id}
                onClick={() => onSelectTask(task)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer bg-white dark:bg-slate-900 ${
                  isDone
                    ? 'border-slate-200 dark:border-slate-800 opacity-60'
                    : 'border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 shadow-xs hover:shadow-sm'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <button
                    type="button"
                    onClick={(e) => handleToggleTask(e, task)}
                    className="mt-0.5 text-slate-400 hover:text-emerald-600 transition-colors cursor-pointer"
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    ) : (
                      <Circle className="w-5 h-5 hover:text-blue-600" />
                    )}
                  </button>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`text-sm font-bold ${
                          isDone
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {task.title}
                      </span>
                    </div>

                    {task.description && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                        {task.description}
                      </p>
                    )}

                    {/* Subtasks Progress */}
                    {totalSubtasks > 0 && (
                      <div className="pt-2 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] text-slate-500">
                          <span>Checklist: {doneSubtasks}/{totalSubtasks} complete</span>
                          <span className="font-bold">{subtaskPercent}%</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full transition-all duration-300"
                            style={{ width: `${subtaskPercent}%` }}
                          />
                        </div>

                        {/* Interactive Subtask items */}
                        <div className="space-y-1 pt-1">
                          {task.subtasks?.map((st) => (
                            <label
                              key={st.id}
                              onClick={(e) => e.stopPropagation()}
                              className="flex items-center space-x-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={st.isCompleted}
                                onChange={(e) => handleToggleSubtask(e as any, task, st.id)}
                                className="w-3.5 h-3.5 text-blue-600 rounded"
                              />
                              <span className={st.isCompleted ? 'line-through text-slate-400' : ''}>
                                {st.title}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Metadata tags */}
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 pt-1">
                      {task.dueDate && (
                        <span className="flex items-center gap-1 font-semibold text-slate-700 dark:text-slate-300">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          Due {task.dueDate}
                        </span>
                      )}

                      {task.timeBlock && (
                        <span className="flex items-center gap-1 text-blue-600 dark:text-blue-400 font-medium">
                          <Clock className="w-3 h-3" />
                          {task.timeBlock.startTime} - {task.timeBlock.endTime}
                        </span>
                      )}

                      <span className="uppercase font-bold text-[10px] px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-900/40">
                        {task.moduleId}
                      </span>

                      {task.priority && (
                        <span
                          className={`font-bold text-[10px] px-2 py-0.5 rounded uppercase ${
                            task.priority === 'critical'
                              ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-900/40'
                              : task.priority === 'high'
                              ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-900/40'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {task.priority}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div id="tasks_view_container" className="space-y-4 pb-24 max-w-6xl mx-auto px-4 sm:px-6 pt-4">
      {/* Top Header & New Task Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-blue-600" />
            <span>Tasks & Pending Work</span>
          </h2>
          <p className="text-xs text-slate-400 font-medium">
            {tasks.filter((t) => t.status !== 'completed').length} pending tasks
          </p>
        </div>

        <button
          type="button"
          id="add_task_btn"
          onClick={onOpenAddTask}
          className="px-4 py-2 bg-blue-600 text-white rounded-full text-xs font-bold shadow-xs hover:bg-blue-700 active:scale-95 flex items-center gap-1.5 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Task</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs scrollbar-none">
        {[
          { id: 'pending', label: 'Pending' },
          { id: 'all', label: 'All' },
          { id: 'in_progress', label: 'In Progress' },
          { id: 'completed', label: 'Completed' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setStatusFilter(tab.id as any)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === tab.id
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Grouped Task List */}
      <div className="space-y-5">
        {renderTaskList(
          groupedTasks.overdue,
          'Overdue Tasks',
          'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/40'
        )}

        {renderTaskList(
          groupedTasks.today,
          'Due Today',
          'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900/40'
        )}

        {renderTaskList(
          groupedTasks.tomorrow,
          'Tomorrow',
          'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-900/40'
        )}

        {renderTaskList(
          groupedTasks.upcoming,
          'Upcoming & Scheduled',
          'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/40'
        )}

        {renderTaskList(
          groupedTasks.noDate,
          'Other Tasks',
          'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
        )}

        {filteredTasks.length === 0 && (
          <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-80" />
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
              No tasks matching filter
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Tap 'Add Task' to create new action items.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
