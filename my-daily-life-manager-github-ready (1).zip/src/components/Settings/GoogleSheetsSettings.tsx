import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Copy,
  Check,
  ExternalLink,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Code2,
  ShieldCheck,
} from 'lucide-react';
import { getSettings, updateSettings } from '../../services/storage';
import { syncToGoogleSheets, APPS_SCRIPT_TEMPLATE } from '../../services/sheetsSync';

export const GoogleSheetsSettings: React.FC = () => {
  const [settings, setSettings] = useState(getSettings());
  const [scriptUrl, setScriptUrl] = useState(settings.sheetsConfig.scriptUrl || '');
  const [spreadsheetId, setSpreadsheetId] = useState(settings.sheetsConfig.spreadsheetId || '');
  const [isTesting, setIsTesting] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [showCode, setShowCode] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(APPS_SCRIPT_TEMPLATE);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleSaveConfig = () => {
    const updated = updateSettings({
      sheetsConfig: {
        ...settings.sheetsConfig,
        scriptUrl: scriptUrl.trim(),
        spreadsheetId: spreadsheetId.trim(),
        isConnected: Boolean(scriptUrl.trim()),
      },
    });
    setSettings(updated);
  };

  const handleTestConnection = async () => {
    handleSaveConfig();
    setIsTesting(true);
    setTestResult(null);

    const result = await syncToGoogleSheets(true);
    setIsTesting(false);
    setTestResult(result);
    setSettings(getSettings());
  };

  return (
    <div id="google_sheets_settings_container" className="space-y-4">
      {/* Header & Status */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Google Sheets Real-Time Sync
              </h3>
              <p className="text-xs text-slate-500">
                Sync all entries directly to your personal Google Sheet via Google Apps Script
              </p>
            </div>
          </div>

          <span
            className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
              settings.sheetsConfig.isConnected
                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            {settings.sheetsConfig.isConnected ? 'Connected' : 'Not Connected'}
          </span>
        </div>
      </div>

      {/* Connection Form */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3.5">
        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
          Webhook URL Configuration
        </h4>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            Google Apps Script Web App URL *
          </label>
          <input
            type="url"
            value={scriptUrl}
            onChange={(e) => setScriptUrl(e.target.value)}
            placeholder="https://script.google.com/macros/s/AKfycb.../exec"
            className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-emerald-500"
          />
          <p className="text-[11px] text-slate-400">
            The published Web App URL from your Google Sheet Extensions &gt; Apps Script deployment.
          </p>
        </div>

        <div className="flex items-center space-x-2 pt-1">
          <button
            type="button"
            onClick={handleSaveConfig}
            className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700"
          >
            Save URL
          </button>

          <button
            type="button"
            disabled={!scriptUrl || isTesting}
            onClick={handleTestConnection}
            className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-emerald-700 active:scale-95 disabled:opacity-50 flex items-center gap-1.5 transition-all"
          >
            {isTesting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
            <span>{isTesting ? 'Testing & Syncing...' : 'Test & Sync Now'}</span>
          </button>
        </div>

        {testResult && (
          <div
            className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
              testResult.success
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200'
            }`}
          >
            {testResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
            <span>{testResult.message}</span>
          </div>
        )}
      </div>

      {/* 3-Step Setup Instructions & Script Template */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>How to setup in Google Sheets (Takes 1 minute)</span>
          </h4>
          <button
            type="button"
            onClick={handleCopyCode}
            className="px-3 py-1 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-indigo-100"
          >
            {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{isCopied ? 'Code Copied!' : 'Copy Script Code'}</span>
          </button>
        </div>

        <ol className="list-decimal list-inside space-y-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed pl-1">
          <li>
            Open any Google Sheet in your browser (or create a new blank one).
          </li>
          <li>
            In the top menu, click <strong>Extensions &gt; Apps Script</strong>.
          </li>
          <li>
            Delete any existing code in the editor, and paste the copied script code.
          </li>
          <li>
            Click <strong>Deploy &gt; New deployment</strong>.
          </li>
          <li>
            Select type: <strong>Web app</strong>, set <em>Execute as</em>: <strong>Me</strong>, and <em>Who has access</em>: <strong>Anyone</strong>.
          </li>
          <li>
            Click <strong>Deploy</strong>, copy the generated Web App URL, and paste it into the box above!
          </li>
        </ol>

        <div className="pt-2">
          <button
            type="button"
            onClick={() => setShowCode(!showCode)}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>{showCode ? 'Hide Apps Script Source Code' : 'View Apps Script Source Code'}</span>
          </button>

          {showCode && (
            <pre className="mt-2 p-3 bg-slate-950 text-emerald-400 font-mono text-[11px] rounded-xl overflow-x-auto max-h-60">
              {APPS_SCRIPT_TEMPLATE}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};
