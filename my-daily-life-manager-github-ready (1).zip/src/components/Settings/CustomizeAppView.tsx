import React, { useState } from 'react';
import {
  Sliders,
  Plus,
  Trash2,
  Archive,
  Edit2,
  FolderPlus,
  Layers,
  Sparkles,
  CheckCircle2,
  Tag,
  Palette,
  X,
} from 'lucide-react';
import {
  CategoryItem,
  ModuleId,
  CustomField,
  CustomTabConfig,
} from '../../types';
import {
  getCategories,
  saveCategory,
  archiveCategory,
  deleteCategory,
  getSettings,
  updateSettings,
  getEntries,
} from '../../services/storage';
import { SafeCategoryModal } from '../Common/ConfirmModal';
import { DynamicIcon } from '../Common/IconRenderer';

export const CustomizeAppView: React.FC = () => {
  const [settings, setSettings] = useState(getSettings());
  const [categories, setCategories] = useState<CategoryItem[]>(getCategories());
  const [activeModule, setActiveModule] = useState<ModuleId>('office');
  
  // New category state
  const [newCatName, setNewCatName] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('Briefcase');
  const [newCatColor, setNewCatColor] = useState('text-blue-500');
  const [newSubcats, setNewSubcats] = useState('');
  
  // Safe delete modal
  const [safeModalData, setSafeModalData] = useState<{
    isOpen: boolean;
    catId: string;
    catName: string;
    usedCount: number;
  }>({ isOpen: false, catId: '', catName: '', usedCount: 0 });

  // New custom field state
  const [showNewField, setShowNewField] = useState(false);
  const [newFieldName, setNewFieldName] = useState('');
  const [newFieldType, setNewFieldType] = useState<CustomField['fieldType']>('text');
  const [newFieldModule, setNewFieldModule] = useState<string>('all');
  const [newFieldOptions, setNewFieldOptions] = useState('');

  const reloadCategories = () => setCategories(getCategories());

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const subcategoryList = newSubcats
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    saveCategory({
      id: `cat-${Date.now()}`,
      moduleId: activeModule,
      name: newCatName.trim(),
      icon: newCatIcon,
      color: newCatColor,
      subcategories: subcategoryList,
      isCustom: true,
      isArchived: false,
    });

    setNewCatName('');
    setNewSubcats('');
    reloadCategories();
  };

  const handleInitiateDeleteCat = (cat: CategoryItem) => {
    const entries = getEntries();
    const usedCount = entries.filter((e) => e.categoryId === cat.id).length;

    if (usedCount > 0) {
      setSafeModalData({
        isOpen: true,
        catId: cat.id,
        catName: cat.name,
        usedCount,
      });
    } else {
      if (window.confirm(`Delete category "${cat.name}"?`)) {
        deleteCategory(cat.id);
        reloadCategories();
      }
    }
  };

  const handleModalArchive = () => {
    archiveCategory(safeModalData.catId);
    setSafeModalData({ isOpen: false, catId: '', catName: '', usedCount: 0 });
    reloadCategories();
  };

  const handleModalForceDelete = () => {
    deleteCategory(safeModalData.catId);
    setSafeModalData({ isOpen: false, catId: '', catName: '', usedCount: 0 });
    reloadCategories();
  };

  const handleAddCustomField = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFieldName.trim()) return;

    const optionsList = newFieldOptions
      .split(',')
      .map((o) => o.trim())
      .filter(Boolean);

    const newField: CustomField = {
      id: `cf-${Date.now()}`,
      name: newFieldName.trim(),
      fieldType: newFieldType,
      moduleId: newFieldModule === 'all' ? undefined : (newFieldModule as ModuleId),
      options: optionsList.length > 0 ? optionsList : undefined,
    };

    const updated = updateSettings({
      customFields: [...settings.customFields, newField],
    });
    setSettings(updated);
    setNewFieldName('');
    setNewFieldOptions('');
    setShowNewField(false);
  };

  const handleDeleteCustomField = (id: string) => {
    const updated = updateSettings({
      customFields: settings.customFields.filter((f) => f.id !== id),
    });
    setSettings(updated);
  };

  const moduleCategories = categories.filter((c) => c.moduleId === activeModule);

  return (
    <div id="customize_app_container" className="space-y-6">
      {/* 1. Categories & Subcategories Manager */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <FolderPlus className="w-4 h-4 text-indigo-600" />
            <span>Category & Subcategory Customizer</span>
          </h3>
          <p className="text-xs text-slate-500">
            Add custom categories or edit subcategories for any module
          </p>
        </div>

        {/* Module Picker */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
          {[
            { id: 'office', label: 'Office' },
            { id: 'union', label: 'Union' },
            { id: 'personal', label: 'Personal' },
            { id: 'home', label: 'Home' },
            { id: 'expense', label: 'Expenses' },
            { id: 'credit', label: 'Credits' },
            { id: 'bills', label: 'Bills' },
            { id: 'tasks', label: 'Tasks' },
            { id: 'notes', label: 'Notes' },
            { id: 'events', label: 'Events' },
            { id: 'wishlist', label: 'Wishlist' },
          ].map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setActiveModule(m.id as ModuleId)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                activeModule === m.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {/* Add New Category Form */}
        <form onSubmit={handleAddCategory} className="bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2.5">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
            + Add New Category for {activeModule}
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <input
              type="text"
              required
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              placeholder="Category name (e.g., Petrol, Overtime, Grievance)"
              className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
            />
            <input
              type="text"
              value={newSubcats}
              onChange={(e) => setNewSubcats(e.target.value)}
              placeholder="Comma-separated subcategories (e.g., Car, Bike, Diesel)"
              className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
            />
          </div>
          <div className="flex justify-end pt-1">
            <button
              type="submit"
              className="px-4 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-indigo-700 active:scale-95"
            >
              Save Category
            </button>
          </div>
        </form>

        {/* Current Categories List */}
        <div className="space-y-2">
          {moduleCategories.map((cat) => (
            <div
              key={cat.id}
              className="flex items-center justify-between p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700"
            >
              <div className="space-y-0.5">
                <div className="flex items-center space-x-2">
                  <DynamicIcon name={cat.icon || 'Folder'} className="w-4 h-4 text-indigo-500" />
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {cat.name}
                  </span>
                  {cat.isArchived && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-bold uppercase">
                      Archived
                    </span>
                  )}
                </div>
                {cat.subcategories.length > 0 && (
                  <p className="text-[11px] text-slate-400 pl-6">
                    Subcategories: {cat.subcategories.join(', ')}
                  </p>
                )}
              </div>

              <div className="flex items-center space-x-1">
                {cat.isArchived ? (
                  <button
                    type="button"
                    onClick={() => {
                      saveCategory({ ...cat, isArchived: false });
                      reloadCategories();
                    }}
                    className="px-2 py-1 text-[10px] font-bold text-indigo-600 hover:bg-indigo-50 rounded"
                  >
                    Unarchive
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleInitiateDeleteCat(cat)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"
                    title="Delete or Archive category"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Custom Fields Builder */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-indigo-600" />
              <span>Dynamic Custom Fields Builder</span>
            </h3>
            <p className="text-xs text-slate-500">
              Add user-defined data fields to forms (Dropdown, Checkbox, Currency, Date, etc.)
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowNewField(!showNewField)}
            className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-bold hover:bg-indigo-100 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Custom Field</span>
          </button>
        </div>

        {/* New Field Creator */}
        {showNewField && (
          <form onSubmit={handleAddCustomField} className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Create New Custom Field
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[11px] text-slate-500">Field Name *</label>
                <input
                  type="text"
                  required
                  value={newFieldName}
                  onChange={(e) => setNewFieldName(e.target.value)}
                  placeholder="e.g. Voucher No, Vehicle KM"
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-500">Field Type</label>
                <select
                  value={newFieldType}
                  onChange={(e) => setNewFieldType(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border rounded-lg text-xs"
                >
                  <option value="text">Text</option>
                  <option value="number">Number</option>
                  <option value="currency">Currency</option>
                  <option value="date">Date</option>
                  <option value="time">Time</option>
                  <option value="dropdown">Dropdown Selection</option>
                  <option value="checkbox">Checkbox (Yes/No)</option>
                  <option value="long_text">Multi-line Long Text</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-500">Attach to Module</label>
                <select
                  value={newFieldModule}
                  onChange={(e) => setNewFieldModule(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border rounded-lg text-xs"
                >
                  <option value="all">All Modules</option>
                  <option value="office">Office</option>
                  <option value="union">Union</option>
                  <option value="personal">Personal</option>
                  <option value="expense">Expense</option>
                  <option value="tasks">Tasks</option>
                </select>
              </div>
            </div>

            {newFieldType === 'dropdown' && (
              <div>
                <label className="text-[11px] text-slate-500">Dropdown Options (Comma-separated)</label>
                <input
                  type="text"
                  value={newFieldOptions}
                  onChange={(e) => setNewFieldOptions(e.target.value)}
                  placeholder="Option 1, Option 2, Option 3"
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border rounded-lg text-xs"
                />
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-1">
              <button
                type="button"
                onClick={() => setShowNewField(false)}
                className="px-3 py-1.5 text-xs text-slate-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold"
              >
                Save Custom Field
              </button>
            </div>
          </form>
        )}

        {/* Existing Custom Fields List */}
        <div className="space-y-2">
          {settings.customFields.length === 0 ? (
            <p className="text-xs text-slate-400 py-3 text-center">No custom fields created yet.</p>
          ) : (
            settings.customFields.map((field) => (
              <div
                key={field.id}
                className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700"
              >
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {field.name}
                  </span>
                  <span className="text-[10px] text-slate-400 ml-2">
                    Type: <strong className="uppercase">{field.fieldType}</strong> • Module: {field.moduleId || 'All'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteCustomField(field.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-500"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Safe Category Deletion Modal */}
      <SafeCategoryModal
        isOpen={safeModalData.isOpen}
        categoryName={safeModalData.catName}
        usedCount={safeModalData.usedCount}
        onCancel={() => setSafeModalData({ isOpen: false, catId: '', catName: '', usedCount: 0 })}
        onArchive={handleModalArchive}
        onForceDelete={handleModalForceDelete}
      />
    </div>
  );
};
