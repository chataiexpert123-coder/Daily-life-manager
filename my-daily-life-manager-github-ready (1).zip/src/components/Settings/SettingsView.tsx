import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Sliders,
  FileSpreadsheet,
  HardDrive,
  Moon,
  Sun,
  Globe,
  DollarSign,
  Palette,
  CheckCircle2,
} from 'lucide-react';
import { getSettings, updateSettings } from '../../services/storage';
import { CustomizeAppView } from './CustomizeAppView';
import { GoogleSheetsSettings } from './GoogleSheetsSettings';
import { BackupRestoreView } from './BackupRestoreView';

interface SettingsViewProps {
  initialTab?: 'general' | 'customize' | 'sheets' | 'backup';
}

export const SettingsView: React.FC<SettingsViewProps> = ({ initialTab = 'general' }) => {
  const [activeTab, setActiveTab] = useState<'general' | 'customize' | 'sheets' | 'backup'>(initialTab);
  const [settings, setSettings] = useState(getSettings());
  const [saveNotice, setSaveNotice] = useState(false);

  const handleUpdate = (partial: Partial<typeof settings>) => {
    const updated = updateSettings(partial);
    setSettings(updated);
    setSaveNotice(true);
    setTimeout(() => setSaveNotice(false), 2000);
  };

  return (
    <div id="settings_view_container" className="space-y-4 pb-24 max-w-4xl mx-auto px-3.5 sm:px-6 pt-3">
      <div>
        <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
          <SettingsIcon className="w-5 h-5 text-indigo-600" />
          <span>Application Settings & Control</span>
        </h2>
        <p className="text-xs text-slate-500">
          Personalize language, currency, appearance, Google Sheets synchronization, and backups
        </p>
      </div>

      {saveNotice && (
        <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Preferences updated!</span>
        </div>
      )}

      {/* Sub navigation tabs */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
        {[
          { id: 'general', label: 'General & Appearance', icon: Sliders },
          { id: 'customize', label: 'Customize Categories & Fields', icon: Palette },
          { id: 'sheets', label: 'Google Sheets Sync', icon: FileSpreadsheet },
          { id: 'backup', label: 'Backup & Restore', icon: HardDrive },
        ].map((tab) => {
          const IconComp = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              id={`settings_tab_${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-xs font-bold'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
              }`}
            >
              <IconComp className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      {activeTab === 'general' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          {/* Theme Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Appearance & Color Theme</span>
            </label>
            <div className="grid grid-cols-3 gap-2 pt-1">
              {[
                { id: 'light', label: 'Light Theme' },
                { id: 'dark', label: 'Dark Theme' },
                { id: 'system', label: 'System Default' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => handleUpdate({ theme: t.id as any })}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                    settings.theme === t.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-700 dark:text-indigo-300 font-bold'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Primary Language */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-indigo-500" />
              <span>Default Language</span>
            </label>
            <div className="grid grid-cols-3 gap-2 pt-1">
              {[
                { id: 'en', label: 'English' },
                { id: 'hi', label: 'हिंदी (Hindi)' },
                { id: 'gu', label: 'ગુજરાતી (Gujarati)' },
              ].map((l) => (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => handleUpdate({ language: l.id as any })}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                    settings.language === l.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-700 dark:text-indigo-300 font-bold'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* Currency Symbol */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-500" />
              <span>Currency Symbol</span>
            </label>
            <div className="flex items-center space-x-2 pt-1">
              {['₹', '$', '€', '£', 'AED'].map((curr) => (
                <button
                  key={curr}
                  type="button"
                  onClick={() => handleUpdate({ currencySymbol: curr })}
                  className={`w-10 h-10 rounded-xl text-xs font-bold border transition-all ${
                    settings.currencySymbol === curr
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {curr}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'customize' && <CustomizeAppView />}
      {activeTab === 'sheets' && <GoogleSheetsSettings />}
      {activeTab === 'backup' && <BackupRestoreView />}
    </div>
  );
};
