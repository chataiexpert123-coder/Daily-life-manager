import React, { useRef, useState } from 'react';
import {
  Download,
  Upload,
  RotateCcw,
  Shield,
  CheckCircle2,
  AlertTriangle,
  HardDrive,
} from 'lucide-react';
import {
  exportFullBackupJSON,
  importFullBackupJSON,
  resetToFactoryDefaults,
  getEntries,
} from '../../services/storage';

export const BackupRestoreView: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const totalEntries = getEntries().length;

  const handleDownloadBackup = () => {
    exportFullBackupJSON();
    setStatusMessage({
      type: 'success',
      text: 'Backup file downloaded successfully! Keep this JSON file safe.',
    });
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      const success = importFullBackupJSON(content);
      if (success) {
        setStatusMessage({
          type: 'success',
          text: 'Backup restored successfully! All your data and settings have been loaded.',
        });
        setTimeout(() => window.location.reload(), 1500);
      } else {
        setStatusMessage({
          type: 'error',
          text: 'Invalid backup file format. Please choose a valid JSON backup.',
        });
      }
    };
    reader.readAsText(file);
    if (e.target) e.target.value = '';
  };

  const handleReset = () => {
    if (
      window.confirm(
        '⚠️ Are you sure you want to reset all data and categories to factory default? This action cannot be undone unless you have a backup.'
      )
    ) {
      resetToFactoryDefaults();
      window.location.reload();
    }
  };

  return (
    <div id="backup_restore_container" className="space-y-4">
      {statusMessage && (
        <div
          className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Security & Privacy Banner */}
      <div className="bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 p-4 rounded-2xl flex items-start space-x-3">
        <div className="p-2 bg-emerald-600 text-white rounded-xl">
          <Shield className="w-5 h-5" />
        </div>
        <div className="space-y-0.5">
          <h4 className="text-xs font-bold text-emerald-950 dark:text-emerald-200">
            100% Offline-First & Private Data Guarantee
          </h4>
          <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed">
            All your daily entries, personal diaries, financial notes, and custom categories stay exclusively on your device. Nothing is sent to third-party tracking servers.
          </p>
        </div>
      </div>

      {/* Backup Card */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-indigo-600 text-white">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                Export Full Backup (JSON)
              </h4>
              <p className="text-[11px] text-slate-500">
                Contains {totalEntries} records, categories, custom fields & settings
              </p>
            </div>
          </div>

          <button
            type="button"
            id="download_backup_btn"
            onClick={handleDownloadBackup}
            className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-xs hover:bg-indigo-700 active:scale-95 transition-all flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Backup</span>
          </button>
        </div>
      </div>

      {/* Restore Card */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-600 text-white">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                Restore from Backup
              </h4>
              <p className="text-[11px] text-slate-500">
                Load previous JSON backup file into your application
              </p>
            </div>
          </div>

          <button
            type="button"
            id="restore_backup_btn"
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 bg-slate-800 dark:bg-slate-700 text-white text-xs font-bold rounded-xl hover:bg-slate-900 active:scale-95 transition-all flex items-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Select JSON File</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={handleFileRestore}
          />
        </div>
      </div>

      {/* Danger Zone: Factory Reset */}
      <div className="bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 p-4 rounded-2xl flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold text-rose-900 dark:text-rose-200">
            Reset Application Data
          </h4>
          <p className="text-[11px] text-rose-700/80 dark:text-rose-300/80">
            Restore sample data, default categories and clear custom entries.
          </p>
        </div>

        <button
          type="button"
          id="factory_reset_btn"
          onClick={handleReset}
          className="px-3.5 py-1.5 text-xs font-bold text-rose-600 border border-rose-300 rounded-xl hover:bg-rose-100 dark:hover:bg-rose-950 transition-colors flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Factory</span>
        </button>
      </div>
    </div>
  );
};
