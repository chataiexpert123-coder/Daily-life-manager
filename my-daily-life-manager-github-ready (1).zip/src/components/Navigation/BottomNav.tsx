import React from 'react';
import { Home, ListFilter, CheckSquare, DollarSign, Menu, Plus } from 'lucide-react';
import { MainNavTab } from '../../types';

interface BottomNavProps {
  activeTab: MainNavTab;
  onChangeTab: (tab: MainNavTab) => void;
  onOpenQuickAdd: () => void;
  pendingTasksCount?: number;
  unpaidBillsCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  onOpenQuickAdd,
  pendingTasksCount = 0,
  unpaidBillsCount = 0,
}) => {
  return (
    <nav
      id="bottom_navigation_bar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-3 sm:px-10 py-2 shadow-lg safe-area-bottom shrink-0"
    >
      <div className="max-w-lg mx-auto flex items-center justify-between relative">
        {/* Left Pair: HOME & ENTRIES */}
        <div className="flex gap-6 sm:gap-12">
          {/* 1. HOME */}
          <button
            type="button"
            id="nav_btn_home"
            onClick={() => onChangeTab('home')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'home'
                ? 'text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 font-medium'
            }`}
          >
            <Home className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">HOME</span>
          </button>

          {/* 2. ENTRIES */}
          <button
            type="button"
            id="nav_btn_entries"
            onClick={() => onChangeTab('entries')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'entries'
                ? 'text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 font-medium'
            }`}
          >
            <ListFilter className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">ENTRIES</span>
          </button>
        </div>

        {/* Central Floating "+" Action Button */}
        <div className="absolute left-1/2 -translate-x-1/2 -top-6">
          <button
            type="button"
            id="floating_quick_add_btn"
            onClick={onOpenQuickAdd}
            aria-label="Quick Add Entry"
            className="w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg border-4 border-white dark:border-slate-900 flex items-center justify-center text-2xl font-bold hover:scale-105 active:scale-95 transition-all shadow-blue-500/30 hover:bg-blue-700"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>

        {/* Right Pair: TASKS & FINANCE (or MORE) */}
        <div className="flex gap-6 sm:gap-12">
          {/* 3. TASKS */}
          <button
            type="button"
            id="nav_btn_tasks"
            onClick={() => onChangeTab('tasks')}
            className={`relative flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'tasks'
                ? 'text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 font-medium'
            }`}
          >
            <CheckSquare className="w-5 h-5 mb-0.5" />
            {pendingTasksCount > 0 && (
              <span className="absolute top-0.5 right-1 w-4 h-4 rounded-full bg-blue-600 text-white text-[9px] font-bold flex items-center justify-center">
                {pendingTasksCount > 9 ? '9+' : pendingTasksCount}
              </span>
            )}
            <span className="text-[10px] font-bold tracking-tight">TASKS</span>
          </button>

          {/* 4. FINANCE */}
          <button
            type="button"
            id="nav_btn_finance"
            onClick={() => onChangeTab('finance')}
            className={`relative flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'finance'
                ? 'text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 font-medium'
            }`}
          >
            <DollarSign className="w-5 h-5 mb-0.5" />
            {unpaidBillsCount > 0 && (
              <span className="absolute top-0.5 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                {unpaidBillsCount > 9 ? '9+' : unpaidBillsCount}
              </span>
            )}
            <span className="text-[10px] font-bold tracking-tight">FINANCE</span>
          </button>

          {/* 5. MORE */}
          <button
            type="button"
            id="nav_btn_more"
            onClick={() => onChangeTab('more')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'more'
                ? 'text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 font-medium'
            }`}
          >
            <Menu className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">MORE</span>
          </button>
        </div>
      </div>
    </nav>
  );
};
