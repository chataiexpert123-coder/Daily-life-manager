import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Briefcase,
  Users,
  User,
  Home,
  TrendingDown,
  TrendingUp,
  Receipt,
  CheckSquare,
  FileText,
  Calendar,
  Camera,
  Mic,
  ArrowRight,
} from 'lucide-react';
import { ModuleId, UniversalEntry } from '../../types';
import { parseNaturalLanguageInput, ParsedEntrySuggestion } from '../../services/aiNaturalParser';
import { UniversalEntryForm } from '../Forms/UniversalEntryForm';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEntrySaved: (entry: UniversalEntry) => void;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onEntrySaved,
}) => {
  const [smartPrompt, setSmartPrompt] = useState('');
  const [suggestion, setSuggestion] = useState<ParsedEntrySuggestion | null>(null);
  const [activeFormModule, setActiveFormModule] = useState<ModuleId | null>(null);
  const [prefilledData, setPrefilledData] = useState<Partial<UniversalEntry> | undefined>(undefined);

  if (!isOpen) return null;

  const handleSmartParse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!smartPrompt.trim()) return;
    const parsed = parseNaturalLanguageInput(smartPrompt);
    setSuggestion(parsed);
  };

  const handleOpenModuleForm = (moduleId: ModuleId, initialData?: Partial<UniversalEntry>) => {
    setActiveFormModule(moduleId);
    setPrefilledData(initialData);
  };

  const handleConfirmSuggestion = () => {
    if (!suggestion) return;
    handleOpenModuleForm(suggestion.moduleId, {
      type: suggestion.type,
      title: suggestion.title,
      description: suggestion.description,
      amount: suggestion.amount,
      categoryId: suggestion.categoryId,
      categoryName: suggestion.categoryName,
      date: suggestion.date,
      time: suggestion.time,
      person: suggestion.person,
      vendorOrPerson: suggestion.person,
      priority: suggestion.priority,
      dueDate: suggestion.dueDate,
      reminder: suggestion.reminder ? { enabled: true, timeOption: '10m', triggered: false } : undefined,
    });
  };

  if (activeFormModule) {
    return (
      <UniversalEntryForm
        isOpen={true}
        initialModuleId={activeFormModule}
        initialEntry={prefilledData}
        onClose={() => {
          setActiveFormModule(null);
          setPrefilledData(undefined);
          onClose();
        }}
        onSaved={(entry) => {
          onEntrySaved(entry);
          setActiveFormModule(null);
          setPrefilledData(undefined);
          onClose();
        }}
      />
    );
  }

  const QUICK_ACTIONS = [
    { id: 'office', label: 'Office', icon: Briefcase, color: 'bg-blue-500 text-white', desc: 'Work, meetings, reports' },
    { id: 'union', label: 'Union', icon: Users, color: 'bg-purple-500 text-white', desc: 'Member issues, circulars' },
    { id: 'personal', label: 'Personal', icon: User, color: 'bg-emerald-500 text-white', desc: 'Calls, plans, tasks' },
    { id: 'home', label: 'Home', icon: Home, color: 'bg-amber-500 text-white', desc: 'Household, repairs, grocery' },
    { id: 'expense', label: 'Expense', icon: TrendingDown, color: 'bg-rose-500 text-white', desc: 'Money spent, bills' },
    { id: 'credit', label: 'Credit', icon: TrendingUp, color: 'bg-green-600 text-white', desc: 'Salary, refund, received' },
    { id: 'bills', label: 'Bill', icon: Receipt, color: 'bg-orange-500 text-white', desc: 'Electricity, mobile, rent' },
    { id: 'tasks', label: 'Task', icon: CheckSquare, color: 'bg-sky-500 text-white', desc: 'To-do, timeline' },
    { id: 'notes', label: 'Note', icon: FileText, color: 'bg-indigo-500 text-white', desc: 'Quick thought, memo' },
    { id: 'events', label: 'Event', icon: Calendar, color: 'bg-teal-500 text-white', desc: 'Scheduled program' },
    { id: 'photo', label: 'Photo', icon: Camera, color: 'bg-pink-500 text-white', desc: 'Camera or receipt snap' },
    { id: 'voice', label: 'Voice', icon: Mic, color: 'bg-red-500 text-white', desc: 'Voice note recording' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center sm:p-4 animate-in fade-in duration-150">
      <div
        id="quick_add_modal_container"
        className="bg-white dark:bg-slate-900 w-full sm:max-w-xl max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-y-auto space-y-4 border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Quick Add Entry
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Tap a type or use natural language
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Smart Natural Language Parser Input */}
        <form onSubmit={handleSmartParse} className="space-y-2">
          <div className="relative">
            <input
              type="text"
              id="smart_natural_input"
              value={smartPrompt}
              onChange={(e) => setSmartPrompt(e.target.value)}
              placeholder="e.g. 'Office me 500 rupees printing expense hua' or 'Kal 11 baje Mahesh sir meeting'"
              className="w-full pl-3.5 pr-20 py-2.5 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
            />
            <button
              type="submit"
              id="smart_parse_btn"
              className="absolute right-1.5 top-1.5 px-3 py-1 bg-indigo-600 text-white text-[11px] font-bold rounded-lg hover:bg-indigo-700 active:scale-95 transition-all flex items-center gap-1"
            >
              <span>Auto</span>
              <Sparkles className="w-3 h-3" />
            </button>
          </div>

          {/* Suggested Parsed Card */}
          {suggestion && (
            <div className="bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80 p-3.5 rounded-xl space-y-2.5 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Smart Detected Suggestion
                </span>
                <span className="text-[10px] px-2 py-0.5 bg-indigo-200 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200 rounded-full font-semibold">
                  {Math.round(suggestion.confidence * 100)}% Match
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500">Module & Type:</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 capitalize">
                    {suggestion.moduleId} • {suggestion.type}
                  </p>
                </div>
                {suggestion.amount !== undefined && (
                  <div>
                    <span className="text-[10px] text-slate-500">Amount:</span>
                    <p className="font-bold text-rose-600 dark:text-rose-400">
                      ₹{suggestion.amount}
                    </p>
                  </div>
                )}
                <div>
                  <span className="text-[10px] text-slate-500">Date & Time:</span>
                  <p className="font-medium text-slate-800 dark:text-slate-200">
                    {suggestion.date} at {suggestion.time}
                  </p>
                </div>
                {suggestion.person && (
                  <div>
                    <span className="text-[10px] text-slate-500">Person:</span>
                    <p className="font-medium text-slate-800 dark:text-slate-200">
                      {suggestion.person}
                    </p>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end space-x-2 pt-1 border-t border-indigo-100 dark:border-indigo-900">
                <button
                  type="button"
                  onClick={() => setSuggestion(null)}
                  className="px-3 py-1 text-xs text-slate-500 hover:text-slate-700"
                >
                  Dismiss
                </button>
                <button
                  type="button"
                  id="confirm_suggestion_btn"
                  onClick={handleConfirmSuggestion}
                  className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold shadow hover:bg-indigo-700 flex items-center gap-1.5"
                >
                  <span>Review & Save</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </form>

        {/* Quick Add Grid */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold tracking-wider uppercase text-slate-400 dark:text-slate-500">
            Select Category / Type
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
            {QUICK_ACTIONS.map((action) => {
              const IconComp = action.icon;
              return (
                <button
                  key={action.id}
                  type="button"
                  id={`quick_btn_${action.id}`}
                  onClick={() => {
                    if (action.id === 'photo') {
                      handleOpenModuleForm('personal', { type: 'Photo / Attachment' });
                    } else if (action.id === 'voice') {
                      handleOpenModuleForm('personal', { type: 'Voice Note' });
                    } else {
                      handleOpenModuleForm(action.id as ModuleId);
                    }
                  }}
                  className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all hover:scale-102 active:scale-95 text-center group"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-1.5 shadow-xs ${action.color} group-hover:scale-105 transition-transform`}>
                    <IconComp className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    + {action.label}
                  </span>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 truncate w-full mt-0.5">
                    {action.desc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
