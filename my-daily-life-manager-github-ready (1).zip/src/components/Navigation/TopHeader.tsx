import React, { useState, useEffect } from 'react';
import { Search, Wifi, WifiOff, CloudCheck, RefreshCw } from 'lucide-react';
import { getSettings } from '../../services/storage';
import { syncToGoogleSheets } from '../../services/sheetsSync';

interface TopHeaderProps {
  onOpenSearch: () => void;
  onOpenNotifications?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  onOpenSearch,
}) => {
  const settings = getSettings();
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const clockTimer = setInterval(() => setCurrentTime(new Date()), 1000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(clockTimer);
    };
  }, []);

  const handleManualSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    try {
      await syncToGoogleSheets(false);
    } finally {
      setIsSyncing(false);
    }
  };

  const formattedDate = currentTime.toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });

  const formattedTime = currentTime.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <header
      id="app_top_header"
      className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-3.5 shrink-0"
    >
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        {/* Title & Live Time */}
        <div className="flex flex-col">
          <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            My Daily Life Manager
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            {formattedDate} • <span className="font-semibold text-slate-700 dark:text-slate-300">{formattedTime}</span>
          </p>
        </div>

        {/* Right Actions: Quick Search Bar, Sync Pill & Avatar */}
        <div className="flex items-center gap-3">
          {/* Search Trigger */}
          <button
            type="button"
            id="header_search_trigger_btn"
            onClick={onOpenSearch}
            className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700/80 rounded-full py-1.5 px-3.5 text-xs text-slate-500 dark:text-slate-400 transition-colors"
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Search everything...</span>
          </button>

          {/* Sync Status Badge */}
          <button
            type="button"
            id="header_sync_status_btn"
            onClick={handleManualSync}
            title={
              !isOnline
                ? 'Offline mode - changes saved locally'
                : settings.sheetsConfig.isConnected
                ? 'Connected to Google Sheets - tap to sync now'
                : 'Local storage active'
            }
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all ${
              !isOnline
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                : settings.sheetsConfig.syncStatus === 'synced'
                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                : settings.sheetsConfig.syncStatus === 'error'
                ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                : 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
            }`}
          >
            {isSyncing ? (
              <RefreshCw className="w-3 h-3 animate-spin text-blue-600 dark:text-blue-400" />
            ) : !isOnline ? (
              <WifiOff className="w-3 h-3 text-amber-600" />
            ) : settings.sheetsConfig.isConnected ? (
              <CloudCheck className="w-3 h-3 text-emerald-600" />
            ) : (
              <Wifi className="w-3 h-3 text-blue-600 dark:text-blue-400" />
            )}
            <span className="text-[11px] font-bold">
              {isSyncing
                ? 'SYNCING...'
                : !isOnline
                ? 'OFFLINE'
                : settings.sheetsConfig.isConnected
                ? 'SHEETS SYNCED'
                : 'LOCAL SYNC'}
            </span>
          </button>

          {/* Avatar Initials Badge */}
          <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-300 shadow-2xs">
            DL
          </div>
        </div>
      </div>
    </header>
  );
};
