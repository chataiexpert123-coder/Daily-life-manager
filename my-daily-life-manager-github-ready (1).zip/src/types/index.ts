export type ModuleId =
  | 'office'
  | 'union'
  | 'personal'
  | 'home'
  | 'expense'
  | 'credit'
  | 'bills'
  | 'tasks'
  | 'notes'
  | 'wishlist'
  | 'affirmations'
  | 'events'
  | string;

export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';

export type EntryStatus =
  | 'pending'
  | 'in_progress'
  | 'completed'
  | 'on_hold'
  | 'cancelled'
  | 'paid'
  | 'overdue'
  | 'idea'
  | 'planned'
  | 'purchased';

export type FieldType =
  | 'text'
  | 'number'
  | 'date'
  | 'time'
  | 'dropdown'
  | 'checkbox'
  | 'currency'
  | 'long_text';

export interface CustomField {
  id: string;
  moduleId?: string; // which module/tab this field belongs to (or undefined for all)
  categoryId?: string; // optional category specific
  name: string;
  fieldType: FieldType;
  options?: string[]; // for dropdowns
  isRequired?: boolean;
  order?: number;
}

export interface SubtaskItem {
  id: string;
  title: string;
  isCompleted: boolean;
}

export interface AttachmentItem {
  id: string;
  name: string;
  type: 'image' | 'pdf' | 'document' | 'other';
  dataUrl?: string; // base64 for images/docs
  size?: number;
  uploadedAt: string;
}

export interface VoiceNoteItem {
  id: string;
  dataUrl: string; // base64 audio data
  durationSeconds: number;
  transcript?: string;
  recordedAt: string;
}

export interface ReminderConfig {
  enabled: boolean;
  timeOption: 'exact' | '5m' | '10m' | '30m' | '1h' | '1d' | 'custom';
  customTime?: string; // YYYY-MM-DDTHH:mm
  recurring?: 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  triggered?: boolean;
}

export interface TimeBlockConfig {
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  durationMinutes?: number;
}

export interface CategoryItem {
  id: string;
  moduleId: string;
  name: string;
  iconName?: string;
  icon?: string;
  color?: string;
  isArchived: boolean;
  order?: number;
  subcategories: string[];
  isCustom?: boolean;
}

export interface CustomTabConfig {
  id: string;
  name: string;
  iconName: string;
  color: string;
  description?: string;
  isEnabled: boolean;
  isArchived: boolean;
  isCustom: boolean;
  order: number;
  defaultCategoryId?: string;
}

export interface UniversalEntry {
  id: string;
  moduleId: ModuleId;
  type: string; // e.g. 'Office work', 'Expense', 'Personal call', 'Meeting', etc.
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  title: string;
  description?: string;
  categoryId?: string;
  categoryName?: string;
  subcategory?: string;
  priority?: PriorityLevel;
  status?: EntryStatus;
  tags: string[];
  
  // Financial fields
  amount?: number;
  paymentMode?: string;
  vendorOrPerson?: string;
  gstNumber?: string;
  billNumber?: string;
  paymentDate?: string;

  // Office & Union specific
  department?: string;
  person?: string;
  organization?: string;
  referenceNumber?: string;
  fileNumber?: string;
  program?: string;
  importantDecision?: string;

  // Task & Planning fields
  dueDate?: string;
  startDate?: string;
  subtasks?: SubtaskItem[];
  timeBlock?: TimeBlockConfig;
  estimatedCost?: number; // Wishlist
  
  // Location & People
  location?: string;
  attendees?: string[];

  // Attachments & Voice
  attachments: AttachmentItem[];
  voiceNote?: VoiceNoteItem;

  // Reminder
  reminder?: ReminderConfig;

  // Dynamic custom fields
  customFieldValues?: Record<string, any>;

  // Metadata
  isArchived: boolean;
  isPinned?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AffirmationItem {
  id: string;
  text: string;
  language: 'en' | 'hi' | 'gu';
  category?: string;
  isActive?: boolean;
  isCustom?: boolean;
  scheduleTime?: string;
  createdAt?: string;
}

export interface DailyDiaryEntry {
  id: string;
  date: string; // YYYY-MM-DD
  summaryText?: string;
  content?: string;
  mood?: 'great' | 'good' | 'neutral' | 'busy' | 'challenging' | 'happy' | 'tired' | 'stressed' | 'excited';
  highlight?: string;
  highlights?: string;
  challenges?: string;
  gratitude?: string;
  tomorrowFocus?: string;
  rating?: number; // 1-5
  createdAt?: string;
  updatedAt: string;
}

export interface DashboardWidgetConfig {
  id: string;
  name: string;
  isEnabled: boolean;
  order: number;
}

export interface GoogleSheetsConfig {
  isConnected: boolean;
  spreadsheetId: string;
  spreadsheetUrl: string;
  webAppUrl: string; // Google Apps Script Webhook URL
  scriptUrl?: string;
  autoSync: boolean;
  lastSynced?: string;
  syncStatus: 'idle' | 'syncing' | 'synced' | 'error';
  syncError?: string;
}

export interface SyncLogItem {
  id: string;
  timestamp: string;
  operation: string;
  status: 'success' | 'failed' | 'queued';
  details: string;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  language: 'en' | 'hi' | 'gu';
  defaultLandingTab: string;
  defaultPaymentModes: string[];
  defaultPriorities: { id: PriorityLevel; label: string; color: string }[];
  defaultStatuses: { id: EntryStatus; label: string; color: string }[];
  defaultTags: string[];
  customFields: CustomField[];
  widgets: DashboardWidgetConfig[];
  sheetsConfig: GoogleSheetsConfig;
  notificationsEnabled: boolean;
  currencySymbol: string;
}

export type MainNavTab = 'home' | 'entries' | 'tasks' | 'finance' | 'more';
export type MoreSubView =
  | 'menu'
  | 'bills'
  | 'notes'
  | 'wishlist'
  | 'affirmations'
  | 'events'
  | 'analytics'
  | 'diary'
  | 'settings'
  | 'customize'
  | 'sheets'
  | 'backup';
