/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MainNavTab, UniversalEntry, ModuleId } from './types';
import { getEntries, getSettings } from './services/storage';
import { TopHeader } from './components/Navigation/TopHeader';
import { BottomNav } from './components/Navigation/BottomNav';
import { QuickAddModal } from './components/Navigation/QuickAddModal';
import { UniversalEntryForm } from './components/Forms/UniversalEntryForm';
import { EntryDetailModal } from './components/Views/EntryDetailModal';
import { GlobalSearchView } from './components/Views/GlobalSearchView';

// Views
import { HomeDashboard } from './components/Views/HomeDashboard';
import { EntriesView } from './components/Views/EntriesView';
import { TasksView } from './components/Views/TasksView';
import { FinanceView } from './components/Views/FinanceView';
import { DailyDiaryView } from './components/Views/DailyDiaryView';
import { MoreMenu } from './components/Views/MoreMenu';
import { NotesView } from './components/Views/NotesView';
import { EventsView } from './components/Views/EventsView';
import { WishlistView } from './components/Views/WishlistView';
import { AffirmationsView } from './components/Views/AffirmationsView';
import { AnalyticsView } from './components/Views/AnalyticsView';
import { SettingsView } from './components/Settings/SettingsView';
import { ArrowLeft } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<MainNavTab>('home');
  const [activeSubView, setActiveSubView] = useState<string | null>(null);
  
  // Modals state
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [activeFormModule, setActiveFormModule] = useState<ModuleId | null>(null);
  const [formInitialData, setFormInitialData] = useState<Partial<UniversalEntry> | undefined>(undefined);
  const [selectedDetailEntry, setSelectedDetailEntry] = useState<UniversalEntry | null>(null);
  
  const [entries, setEntries] = useState<UniversalEntry[]>(getEntries());
  const settings = getSettings();

  const refreshData = () => {
    setEntries(getEntries());
  };

  // Sync theme
  useEffect(() => {
    const isDark =
      settings.theme === 'dark' ||
      (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.theme]);

  // Counts for bottom navigation badges
  const pendingTasksCount = entries.filter(
    (e) => (e.moduleId === 'tasks' || e.type === 'Task') && e.status !== 'completed' && !e.isArchived
  ).length;

  const unpaidBillsCount = entries.filter(
    (e) => (e.moduleId === 'bills' || e.type === 'Bill') && e.status !== 'paid' && !e.isArchived
  ).length;

  const handleOpenModuleForm = (moduleId: ModuleId, initialData?: Partial<UniversalEntry>) => {
    setActiveFormModule(moduleId);
    setFormInitialData(initialData);
  };

  const handleSelectMoreOption = (optionId: string) => {
    setActiveSubView(optionId);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* 1. Sticky Top Navigation Header */}
      <TopHeader
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Sub-view back navigation header when inside a sub-module */}
      {activeSubView && (
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-2.5 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setActiveSubView(null)}
            className="flex items-center space-x-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Menu</span>
          </button>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            {activeSubView}
          </span>
        </div>
      )}

      {/* 2. Main Body Content Area */}
      <main className="flex-1">
        {activeSubView === 'diary' ? (
          <DailyDiaryView />
        ) : activeSubView === 'wishlist' ? (
          <WishlistView
            onOpenAddWishlist={() => handleOpenModuleForm('wishlist')}
            onSelectEntry={(entry) => setSelectedDetailEntry(entry)}
          />
        ) : activeSubView === 'notes' ? (
          <NotesView
            onOpenAddNote={() => handleOpenModuleForm('notes')}
            onSelectNote={(note) => setSelectedDetailEntry(note)}
          />
        ) : activeSubView === 'events' ? (
          <EventsView
            onOpenAddEvent={() => handleOpenModuleForm('events')}
            onSelectEvent={(event) => setSelectedDetailEntry(event)}
          />
        ) : activeSubView === 'affirmations' ? (
          <AffirmationsView />
        ) : activeSubView === 'analytics' ? (
          <AnalyticsView />
        ) : activeSubView === 'customize' ? (
          <SettingsView initialTab="customize" />
        ) : activeSubView === 'sheets' ? (
          <SettingsView initialTab="sheets" />
        ) : activeSubView === 'backup' ? (
          <SettingsView initialTab="backup" />
        ) : activeSubView === 'settings' ? (
          <SettingsView initialTab="general" />
        ) : activeTab === 'home' ? (
          <HomeDashboard
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
            onOpenModuleForm={handleOpenModuleForm}
            onNavigateTab={(tab) => {
              setActiveSubView(null);
              setActiveTab(tab);
            }}
            onSelectEntry={(entry) => setSelectedDetailEntry(entry)}
          />
        ) : activeTab === 'entries' ? (
          <EntriesView
            onOpenAddModal={(mod) => handleOpenModuleForm(mod || 'personal')}
            onSelectEntry={(entry) => setSelectedDetailEntry(entry)}
          />
        ) : activeTab === 'tasks' ? (
          <TasksView
            onOpenAddTask={() => handleOpenModuleForm('tasks')}
            onSelectTask={(task) => setSelectedDetailEntry(task)}
          />
        ) : activeTab === 'finance' ? (
          <FinanceView
            onOpenAddFinance={(mod) => handleOpenModuleForm(mod)}
            onSelectEntry={(entry) => setSelectedDetailEntry(entry)}
          />
        ) : activeTab === 'more' ? (
          <MoreMenu onSelectOption={handleSelectMoreOption} />
        ) : null}
      </main>

      {/* 3. Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(tab) => {
          setActiveSubView(null);
          setActiveTab(tab);
        }}
        onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        pendingTasksCount={pendingTasksCount}
        unpaidBillsCount={unpaidBillsCount}
      />

      {/* 4. Quick Add Modal */}
      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onEntrySaved={(entry) => {
          refreshData();
        }}
      />

      {/* 5. Direct Module Entry Form */}
      {activeFormModule && (
        <UniversalEntryForm
          isOpen={true}
          initialModuleId={activeFormModule}
          initialEntry={formInitialData}
          onClose={() => {
            setActiveFormModule(null);
            setFormInitialData(undefined);
          }}
          onSaved={(entry) => {
            refreshData();
            setActiveFormModule(null);
            setFormInitialData(undefined);
          }}
        />
      )}

      {/* 6. Entry Detail & Inspect Modal */}
      <EntryDetailModal
        isOpen={Boolean(selectedDetailEntry)}
        entry={selectedDetailEntry}
        onClose={() => setSelectedDetailEntry(null)}
        onEntryUpdated={() => {
          refreshData();
          if (selectedDetailEntry) {
            const updated = getEntries().find((e) => e.id === selectedDetailEntry.id);
            setSelectedDetailEntry(updated || null);
          }
        }}
      />

      {/* 7. Global Search Modal */}
      <GlobalSearchView
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectEntry={(entry) => setSelectedDetailEntry(entry)}
      />
    </div>
  );
}
